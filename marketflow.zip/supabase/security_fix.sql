-- MarketFlow post-deployment security fixes
-- Run once after staff_system.sql as a Supabase project owner.
-- Safe to rerun.

begin;

-- Keep this repair safe if only the base products table was created.
alter table public.products add column if not exists name_ar text;
alter table public.products add column if not exists name_en text;
alter table public.products add column if not exists area text default 'in';
alter table public.products add column if not exists category text default 'produce';
alter table public.products add column if not exists compare_at_price numeric;
alter table public.products add column if not exists offer_ar text;
alter table public.products add column if not exists offer_en text;
alter table public.products add column if not exists image_key text default 'produce';

-- staff_system.sql enables RLS on profiles. Allow a signed-in user to read
-- only their own role, and allow owners to read profiles for administration.
drop policy if exists profiles_self_read on public.profiles;
create policy profiles_self_read on public.profiles
  for select to authenticated
  using (id = auth.uid() or public.my_role() = 'owner');

-- RLS is row-level only; selecting * from products would otherwise expose
-- the private cost column to anonymous clients. Keep cost available to
-- server-side functions while exposing only catalog-safe columns to clients.
revoke select on public.products from anon, authenticated;
grant select (
  id, name, name_ar, name_en, price, stock, area, category, active,
  updated_at, compare_at_price, offer_ar, offer_en, image_key
) on public.products to anon, authenticated;

commit;
