// Supabase Edge Function "staff-admin"  (file: supabase/functions/staff-admin/index.ts)
// Deploy:  supabase functions deploy staff-admin
// The service-role key stays on the server (Supabase provides it automatically).
// - Any active staff member can change their OWN password (must know the current one).
// - Only an active OWNER can create/edit/disable/delete cashier accounts and edit his own name/username.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};
const json = (b: unknown) =>
  new Response(JSON.stringify(b), { headers: { ...cors, 'Content-Type': 'application/json' } });
const fail = (error: string) => json({ ok: false, error });
const USERNAME = /^[a-z0-9_.]{3,20}$/;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors });
  try {
    const url = Deno.env.get('SUPABASE_URL')!;
    const admin = createClient(url, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    const token = (req.headers.get('Authorization') || '').replace('Bearer ', '');
    const { data: u, error: ue } = await admin.auth.getUser(token);
    if (ue || !u.user) return fail('not signed in');
    const { data: me } = await admin.from('profiles').select('role,active,email,username').eq('id', u.user.id).single();
    if (!me || !me.active || !['owner', 'cashier'].includes(me.role)) return fail('not allowed');

    const b = await req.json();
    const log = (action: string, ref: string, details: unknown) =>
      admin.from('audit_log').insert({ user_id: u.user!.id, user_email: me.email, action, ref, details });

    // ----- any staff: change my own password -----
    if (b.action === 'change_own_password') {
      const password = String(b.password || '');
      if (password.length < 8) return fail('password must be at least 8 characters');
      const anon = createClient(url, Deno.env.get('SUPABASE_ANON_KEY')!, {
        auth: { persistSession: false, autoRefreshToken: false },
      });
      const { error: se } = await anon.auth.signInWithPassword({ email: u.user.email!, password: String(b.current || '') });
      if (se) return fail('current password is wrong');
      const { error } = await admin.auth.admin.updateUserById(u.user.id, { password });
      if (error) return fail(error.message);
      await log('staff_password', u.user.id, { username: me.username });
      return json({ ok: true });
    }

    // ----- owner only from here -----
    if (me.role !== 'owner') return fail('owner only');

    if (b.action === 'create') {
      const username = String(b.username || '').trim().toLowerCase();
      const password = String(b.password || '');
      const fullName = String(b.full_name || '').trim();
      if (!USERNAME.test(username)) return fail('username: 3-20 letters/numbers');
      if (password.length < 8) return fail('password must be at least 8 characters');
      if (!fullName) return fail('name is required');
      const { data: taken } = await admin.from('profiles').select('id').eq('username', username).maybeSingle();
      if (taken) return fail('username already exists');
      const { data: created, error } = await admin.auth.admin.createUser({
        email: `${username}@store.local`, password, email_confirm: true, user_metadata: { full_name: fullName },
      });
      if (error || !created.user) return fail(error?.message || 'could not create user');
      const { error: pe } = await admin.from('profiles').update({
        role: 'cashier', username, full_name: fullName, phone: String(b.phone || '').trim() || null, active: true,
      }).eq('id', created.user.id);
      if (pe) { await admin.auth.admin.deleteUser(created.user.id); return fail(pe.message); }
      await log('staff_create', created.user.id, { username });
      return json({ ok: true, id: created.user.id });
    }

    // edit a cashier (name, username, phone, optional new password) or the owner's own name/username
    if (b.action === 'update_staff') {
      const { data: t } = await admin.from('profiles').select('id,role,username,email').eq('id', String(b.id)).single();
      const self = !!t && t.id === u.user.id;
      if (!t || !(t.role === 'cashier' || self)) return fail('account not found');
      const patch: Record<string, unknown> = {};
      const changed: string[] = [];
      if (b.username !== undefined) {
        const username = String(b.username).trim().toLowerCase();
        if (!USERNAME.test(username)) return fail('username: 3-20 letters/numbers');
        if (username !== t.username) {
          const { data: taken } = await admin.from('profiles').select('id').eq('username', username).neq('id', t.id).maybeSingle();
          if (taken) return fail('username already exists');
          const email = `${username}@store.local`;
          const { error } = await admin.auth.admin.updateUserById(t.id, { email, email_confirm: true });
          if (error) return fail(error.message);
          patch.username = username; patch.email = email; changed.push('username');
        }
      }
      if (b.full_name !== undefined) {
        const n = String(b.full_name).trim();
        if (!n) return fail('name is required');
        patch.full_name = n;
      }
      if (b.phone !== undefined) patch.phone = String(b.phone).trim() || null;
      if (b.password) {
        if (self) return fail('use change password for your own account');
        const password = String(b.password);
        if (password.length < 8) return fail('password must be at least 8 characters');
        const { error } = await admin.auth.admin.updateUserById(t.id, { password });
        if (error) return fail(error.message);
        changed.push('password');
      }
      if (Object.keys(patch).length) {
        const { error } = await admin.from('profiles').update(patch).eq('id', t.id);
        if (error) return fail(error.message);
      }
      await log('staff_update', t.id, { username: (patch.username as string) || t.username, old_username: t.username, changed });
      return json({ ok: true });
    }

    const cashier = async (id: string) => {
      const { data } = await admin.from('profiles').select('id,role,username').eq('id', id).single();
      return data && data.role === 'cashier' ? data : null;
    };

    if (b.action === 'set_active') {
      const t = await cashier(String(b.id));
      if (!t) return fail('cashier not found');
      const active = !!b.active;
      const { error } = await admin.from('profiles').update({ active, status: active ? 'active' : 'disabled' }).eq('id', t.id);
      if (error) return fail(error.message);
      await admin.auth.admin.updateUserById(t.id, { ban_duration: active ? 'none' : '876000h' });
      await log('staff_active', t.id, { username: t.username, active });
      return json({ ok: true });
    }

    if (b.action === 'delete') {
      const t = await cashier(String(b.id));
      if (!t) return fail('cashier not found');
      const s = await admin.from('sales').select('id', { count: 'exact', head: true }).eq('cashier_id', t.id);
      const h = await admin.from('shifts').select('id', { count: 'exact', head: true }).eq('cashier_id', t.id);
      if ((s.count || 0) > 0 || (h.count || 0) > 0) return fail('this cashier has activity: disable the account instead');
      const { error } = await admin.auth.admin.deleteUser(t.id);
      if (error) return fail(error.message);
      await log('staff_delete', t.id, { username: t.username });
      return json({ ok: true });
    }

    return fail('unknown action');
  } catch (e) {
    return fail(String((e as Error).message || e));
  }
});
