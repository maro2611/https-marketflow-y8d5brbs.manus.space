-- MarketFlow demo catalog setup
-- Run this once in Supabase SQL Editor as a project owner.
-- It is intentionally idempotent: re-running it does not duplicate demo products.

begin;

alter table public.products add column if not exists name_ar text;
alter table public.products add column if not exists name_en text;
alter table public.products add column if not exists area text default 'in';
alter table public.products add column if not exists category text default 'produce';
alter table public.products add column if not exists compare_at_price numeric;
alter table public.products add column if not exists offer_ar text;
alter table public.products add column if not exists offer_en text;
alter table public.products add column if not exists image_key text default 'produce';

update public.products
set name_ar = coalesce(name_ar, name),
    name_en = coalesce(name_en, name),
    area = coalesce(area, 'in'),
    category = coalesce(category, 'pantry'),
    image_key = coalesce(image_key, 'pantry'),
    active = coalesce(active, true),
    updated_at = coalesce(updated_at, now());

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Fresh Tomatoes', 'طماطم طازجة', 'Fresh Tomatoes', 28, 42, 'in', 'produce', true, now(), 34, 'عرض اليوم', 'Today''s deal', 'produce'
where not exists (select 1 from public.products where name = 'Fresh Tomatoes');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Egyptian Oranges', 'برتقال مصري', 'Egyptian Oranges', 45, 30, 'out', 'produce', true, now(), 52, 'صندوق العائلة', 'Family box', 'produce'
where not exists (select 1 from public.products where name = 'Egyptian Oranges');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Full Cream Milk', 'لبن كامل الدسم', 'Full Cream Milk', 38, 26, 'in', 'dairy', true, now(), null, null, null, 'dairy'
where not exists (select 1 from public.products where name = 'Full Cream Milk');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'White Cheese', 'جبنة بيضاء', 'White Cheese', 74, 14, 'in', 'dairy', true, now(), 82, 'خصم 10%', '10% off', 'dairy'
where not exists (select 1 from public.products where name = 'White Cheese');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Baladi Bread', 'عيش بلدي', 'Baladi Bread', 12, 70, 'in', 'bakery', true, now(), null, 'طازج كل صباح', 'Fresh every morning', 'bakery'
where not exists (select 1 from public.products where name = 'Baladi Bread');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Butter Croissant', 'كرواسون بالزبدة', 'Butter Croissant', 32, 9, 'out', 'bakery', true, now(), null, null, null, 'bakery'
where not exists (select 1 from public.products where name = 'Butter Croissant');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Jasmine Rice 1kg', 'أرز بسمتي ١ كجم', 'Jasmine Rice 1kg', 68, 24, 'in', 'pantry', true, now(), 76, 'سعر خاص', 'Special price', 'pantry'
where not exists (select 1 from public.products where name = 'Jasmine Rice 1kg');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Olive Oil 750ml', 'زيت زيتون ٧٥٠ مل', 'Olive Oil 750ml', 185, 8, 'out', 'pantry', true, now(), null, null, null, 'pantry'
where not exists (select 1 from public.products where name = 'Olive Oil 750ml');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Sparkling Water', 'مياه غازية', 'Sparkling Water', 22, 36, 'out', 'drinks', true, now(), 26, 'اشترِ ٢ ووفر', 'Buy 2 and save', 'drinks'
where not exists (select 1 from public.products where name = 'Sparkling Water');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Mango Juice', 'عصير مانجو', 'Mango Juice', 29, 18, 'in', 'drinks', true, now(), null, null, null, 'drinks'
where not exists (select 1 from public.products where name = 'Mango Juice');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Sea Salt Chips', 'شيبسي ملح البحر', 'Sea Salt Chips', 18, 0, 'out', 'snacks', true, now(), null, null, null, 'snacks'
where not exists (select 1 from public.products where name = 'Sea Salt Chips');

insert into public.products
  (name, name_ar, name_en, price, stock, area, category, active, updated_at, compare_at_price, offer_ar, offer_en, image_key)
select 'Chocolate Bites', 'لقيمات شوكولاتة', 'Chocolate Bites', 44, 12, 'in', 'snacks', true, now(), 49, 'اختيار الأسبوع', 'Pick of the week', 'snacks'
where not exists (select 1 from public.products where name = 'Chocolate Bites');

create index if not exists products_active_area_idx on public.products (active, area);
create index if not exists products_category_idx on public.products (category);

commit;

-- Optional verification:
-- select id, name_ar, name_en, price, stock, area, category, active from public.products order by id;
