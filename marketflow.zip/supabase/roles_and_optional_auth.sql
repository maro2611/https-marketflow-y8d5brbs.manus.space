-- MarketFlow optional accounts and owner allowlist
-- Run after demo_seed.sql as a Supabase project owner.

begin;

create table if not exists public.owner_allowlist (
  email text primary key,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table public.owner_allowlist enable row level security;
drop policy if exists owner_allowlist_owner_read on public.owner_allowlist;
create policy owner_allowlist_owner_read on public.owner_allowlist
  for select to authenticated
  using (exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'owner'));

create or replace function public.add_owner_email(p_email text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare requester_role text;
begin
  select role into requester_role from public.profiles where id = auth.uid();
  if requester_role is distinct from 'owner' then
    raise exception 'Only an owner can add owner emails';
  end if;

  insert into public.owner_allowlist(email, created_by)
  values (lower(trim(p_email)), auth.uid())
  on conflict (email) do nothing;

  update public.profiles
  set role = 'owner'
  where id in (select id from auth.users where lower(email) = lower(trim(p_email)));
end;
$$;

revoke all on function public.add_owner_email(text) from public;
grant execute on function public.add_owner_email(text) to authenticated;

create or replace function public.sync_my_owner_role()
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.profiles p
  set role = 'owner'
  where p.id = auth.uid()
    and exists (
      select 1 from public.owner_allowlist a
      where lower(a.email) = lower((select email from auth.users where id = p.id))
    );
end;
$$;

revoke all on function public.sync_my_owner_role() from public;
grant execute on function public.sync_my_owner_role() to authenticated;

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, role)
  values (
    new.id,
    case when exists (
      select 1 from public.owner_allowlist a where lower(a.email) = lower(new.email)
    ) then 'owner' else 'pending' end
  )
  on conflict (id) do update set role = excluded.role;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

commit;

-- Bootstrap the official owner email supplied by the project owner.
insert into public.owner_allowlist(email)
values ('marcelinofahmyatiia@gmail.com')
on conflict do nothing;

update public.profiles
set role = 'owner'
where id in (select id from auth.users where lower(email) = 'marcelinofahmyatiia@gmail.com');

insert into public.profiles (id, role)
select id, 'owner'
from auth.users
where lower(email) = 'marcelinofahmyatiia@gmail.com'
on conflict (id) do update set role = 'owner';

-- Email confirmation must remain a Supabase Auth setting or admin-side action;
-- never bypass it from the browser/client code.
