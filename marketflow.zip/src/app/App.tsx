import { useEffect, useState } from 'react'
import { AccountAuth } from '../features/auth/Auth'
import { Catalog } from '../features/catalog/Catalog'
import { StaffConsole, StaffLogin } from '../features/staff/Staff'
import { addOwnerEmail as addOwnerEmailRemote, getCurrentAccount, isSupabaseConfigured, signInStaff, signOutStaff, subscribeToAuth } from '../shared/supabase'
import { loadLocale, loadSession, saveLocale } from '../shared/storage'
import { useActivities, useCatalog } from '../shared/utils'
import type { Locale, UserAccount } from '../shared/types'

function currentPath() { return window.location.pathname.replace(/\/+$/, '') || '/' }

export function App() {
  const [path, setPath] = useState(currentPath)
  const [locale, setLocale] = useState<Locale>(() => loadLocale())
  const [session, setSession] = useState(() => loadSession())
  const [account, setAccount] = useState<UserAccount | null>(null)
  const [authReady, setAuthReady] = useState(!isSupabaseConfigured)
  const { products, lastUpdated, commit } = useCatalog()
  const { activities, addActivity } = useActivities()

  useEffect(() => {
    const handlePopState = () => setPath(currentPath())
    window.addEventListener('popstate', handlePopState)
    return () => window.removeEventListener('popstate', handlePopState)
  }, [])

  useEffect(() => {
    document.documentElement.lang = locale
    document.documentElement.dir = locale === 'ar' ? 'rtl' : 'ltr'
    saveLocale(locale)
  }, [locale])

  useEffect(() => {
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => undefined)
  }, [])

  useEffect(() => {
    if (!isSupabaseConfigured) return
    let active = true
    void getCurrentAccount()
      .then((user) => { if (active) setAccount(user) })
      .catch(() => { if (active) setAccount(null) })
      .finally(() => { if (active) setAuthReady(true) })
    const unsubscribe = subscribeToAuth((user) => {
      if (active) setAccount(user)
    })
    return () => { active = false; unsubscribe() }
  }, [])

  const navigate = (nextPath: string) => {
    if (nextPath !== currentPath()) window.history.pushState({}, '', nextPath)
    setPath(nextPath)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const staffLogin = async (email: string, password: string) => {
    if (isSupabaseConfigured) {
      const user = await signInStaff(email, password)
      if (user.role === 'pending') {
        await signOutStaff()
        setAccount(null)
        throw new Error('pending')
      }
      setAccount(user)
      navigate('/staff')
      return
    }
    setSession({ name: email.trim() })
    navigate('/staff')
  }

  const publicSignOut = () => {
    if (isSupabaseConfigured) void signOutStaff().catch((error) => console.error('Supabase sign out failed', error))
    setAccount(null)
    setSession(null)
    window.localStorage.removeItem('marketflow-staff-session-v1')
    navigate('/')
  }

  const onLocaleChange = (nextLocale: Locale) => setLocale(nextLocale)
  const remoteStaffName = account?.fullName || account?.email || ''

  if (path === '/login') return <AccountAuth locale={locale} onLocaleChange={onLocaleChange} onNavigate={navigate} onAuthenticated={setAccount} />
  if (path === '/staff/login') return <StaffLogin locale={locale} onLocaleChange={onLocaleChange} onNavigate={navigate} onLoggedIn={staffLogin} remoteMode={isSupabaseConfigured} />
  if (path === '/staff') {
    if (isSupabaseConfigured && !authReady) return <main className="staff-loading"><p>{locale === 'ar' ? 'جارٍ التحقق من الجلسة...' : 'Checking your session...'}</p></main>
    if (isSupabaseConfigured && (!account || account.role === 'pending')) return <StaffLogin locale={locale} onLocaleChange={onLocaleChange} onNavigate={navigate} onLoggedIn={staffLogin} remoteMode={true} initialError={account ? (locale === 'ar' ? 'هذا الحساب عادي. سجّل الدخول بحساب موظف أو مالك.' : 'This is a customer account. Use an owner or cashier account.') : undefined} />
    if (!isSupabaseConfigured && !session) return <StaffLogin locale={locale} onLocaleChange={onLocaleChange} onNavigate={navigate} onLoggedIn={staffLogin} remoteMode={false} />
    return <StaffConsole locale={locale} onLocaleChange={onLocaleChange} onNavigate={navigate} userName={isSupabaseConfigured ? remoteStaffName : session?.name || ''} role={isSupabaseConfigured ? account?.role || 'pending' : 'owner'} products={products} activities={activities} lastUpdated={lastUpdated} commit={commit} addActivity={addActivity} onSignOut={publicSignOut} remoteMode={isSupabaseConfigured} onAddOwnerEmail={addOwnerEmailRemote} />
  }
  return <Catalog locale={locale} products={products} lastUpdated={lastUpdated} onLocaleChange={onLocaleChange} onNavigate={navigate} />
}
