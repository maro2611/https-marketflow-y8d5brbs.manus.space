import type { CategoryId, LocalizedText, Product } from './types'

export const AREA_LABELS: Record<'inside' | 'outside', LocalizedText> = {
  inside: { ar: 'داخل المتجر', en: 'Inside the shop' },
  outside: { ar: 'المنطقة الخارجية', en: 'Outside area' },
}

export const CATEGORY_LABELS: Record<CategoryId, LocalizedText> = {
  produce: { ar: 'خضار وفاكهة', en: 'Produce' },
  dairy: { ar: 'ألبان', en: 'Dairy' },
  bakery: { ar: 'مخبوزات', en: 'Bakery' },
  pantry: { ar: 'مؤن أساسية', en: 'Pantry' },
  drinks: { ar: 'مشروبات', en: 'Drinks' },
  snacks: { ar: 'تسالي', en: 'Snacks' },
}

export const CATEGORY_ORDER: CategoryId[] = ['produce', 'dairy', 'bakery', 'pantry', 'drinks', 'snacks']

export const PRODUCT_VISUALS: Record<string, { emoji: string; tone: string }> = {
  produce: { emoji: '🍊', tone: 'visual-orange' },
  leafy: { emoji: '🥬', tone: 'visual-leafy' },
  dairy: { emoji: '🥛', tone: 'visual-dairy' },
  bakery: { emoji: '🥖', tone: 'visual-bakery' },
  pantry: { emoji: '🫒', tone: 'visual-pantry' },
  rice: { emoji: '🍚', tone: 'visual-rice' },
  drinks: { emoji: '🧃', tone: 'visual-drinks' },
  snacks: { emoji: '🥨', tone: 'visual-snacks' },
  coffee: { emoji: '☕', tone: 'visual-coffee' },
  outdoor: { emoji: '🌱', tone: 'visual-outdoor' },
}

const at = (minutesAgo: number) => new Date(Date.now() - minutesAgo * 60_000).toISOString()

export const SEED_PRODUCTS: Product[] = [
  {
    id: 'oranges',
    name: { ar: 'برتقال بلدي', en: 'Local oranges' },
    category: { id: 'produce', label: CATEGORY_LABELS.produce },
    area: 'outside', price: 38, compareAtPrice: 45, availability: 'in_stock', image: 'produce',
    offer: { ar: 'عرض الأسبوع', en: 'Weekly offer' }, updatedAt: at(8),
  },
  {
    id: 'lettuce',
    name: { ar: 'خس طازج', en: 'Fresh lettuce' },
    category: { id: 'produce', label: CATEGORY_LABELS.produce },
    area: 'outside', price: 22, availability: 'in_stock', image: 'leafy', updatedAt: at(14),
  },
  {
    id: 'milk',
    name: { ar: 'حليب كامل الدسم', en: 'Full-fat milk' },
    category: { id: 'dairy', label: CATEGORY_LABELS.dairy },
    area: 'inside', price: 42, compareAtPrice: 46, availability: 'in_stock', image: 'dairy',
    offer: { ar: 'سعر خاص', en: 'Special price' }, updatedAt: at(22),
  },
  {
    id: 'bread',
    name: { ar: 'خبز بلدي طازج', en: 'Fresh baladi bread' },
    category: { id: 'bakery', label: CATEGORY_LABELS.bakery },
    area: 'inside', price: 18, availability: 'in_stock', image: 'bakery', updatedAt: at(31),
  },
  {
    id: 'olive-oil',
    name: { ar: 'زيت زيتون بكر', en: 'Extra virgin olive oil' },
    category: { id: 'pantry', label: CATEGORY_LABELS.pantry },
    area: 'inside', price: 245, compareAtPrice: 280, availability: 'in_stock', image: 'pantry',
    offer: { ar: 'خصم ١٢٪', en: '12% off' }, updatedAt: at(43),
  },
  {
    id: 'rice',
    name: { ar: 'أرز مصري فاخر', en: 'Premium Egyptian rice' },
    category: { id: 'pantry', label: CATEGORY_LABELS.pantry },
    area: 'inside', price: 68, availability: 'in_stock', image: 'rice', updatedAt: at(55),
  },
  {
    id: 'juice',
    name: { ar: 'عصير مانجو طبيعي', en: 'Natural mango juice' },
    category: { id: 'drinks', label: CATEGORY_LABELS.drinks },
    area: 'outside', price: 34, availability: 'in_stock', image: 'drinks', updatedAt: at(68),
  },
  {
    id: 'pretzels',
    name: { ar: 'بريتزل بالملح', en: 'Sea-salt pretzels' },
    category: { id: 'snacks', label: CATEGORY_LABELS.snacks },
    area: 'outside', price: 29, compareAtPrice: 35, availability: 'out_of_stock', image: 'snacks',
    offer: { ar: 'ينتظر التوريد', en: 'Restocking soon' }, updatedAt: at(75),
  },
  {
    id: 'coffee',
    name: { ar: 'قهوة محوجة', en: 'Spiced coffee' },
    category: { id: 'drinks', label: CATEGORY_LABELS.drinks },
    area: 'inside', price: 155, availability: 'in_stock', image: 'coffee', updatedAt: at(92),
  },
  {
    id: 'garden-herbs',
    name: { ar: 'أعشاب زراعية', en: 'Garden herbs' },
    category: { id: 'produce', label: CATEGORY_LABELS.produce },
    area: 'outside', price: 48, availability: 'in_stock', image: 'outdoor',
    offer: { ar: 'وصل حديثاً', en: 'Just arrived' }, updatedAt: at(109),
  },
  {
    id: 'yogurt',
    name: { ar: 'زبادي طبيعي', en: 'Natural yogurt' },
    category: { id: 'dairy', label: CATEGORY_LABELS.dairy },
    area: 'inside', price: 25, availability: 'in_stock', image: 'dairy', updatedAt: at(126),
  },
  {
    id: 'biscuits',
    name: { ar: 'بسكويت بالزبدة', en: 'Butter biscuits' },
    category: { id: 'snacks', label: CATEGORY_LABELS.snacks },
    area: 'inside', price: 32, availability: 'in_stock', image: 'snacks', updatedAt: at(143),
  },
]

export const DEFAULT_ACTIVITIES = [
  { id: 'activity-1', action: 'updated' as const, productName: SEED_PRODUCTS[0].name, detail: { ar: 'تم تحديث سعر البرتقال', en: 'Orange price updated' }, at: at(8) },
  { id: 'activity-2', action: 'availability' as const, productName: SEED_PRODUCTS[7].name, detail: { ar: 'تم تغيير حالة البريتزل', en: 'Pretzel stock status changed' }, at: at(75) },
  { id: 'activity-3', action: 'created' as const, productName: SEED_PRODUCTS[9].name, detail: { ar: 'تمت إضافة منتج جديد', en: 'New product added' }, at: at(109) },
]
