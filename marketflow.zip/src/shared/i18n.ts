import type { Locale, Product } from './types'

export const COPY = {
  ar: {
    catalog: 'الكتالوج', staffLogin: 'دخول الموظفين', staffWorkspace: 'مساحة الموظفين',
    brandTagline: 'متجر واحد، كل شيء قريب', heroTitle: 'اختياراتك اليومية، أوضح وأسهل',
    heroBody: 'تصفح المنتجات المتاحة داخل المتجر وفي المنطقة الخارجية. الأسعار والتوافر محدثان من فريقنا مباشرة.',
    browseCatalog: 'تصفح المنتجات', updatedLive: 'محدث مباشرة', freshInventory: 'مخزون اليوم',
    productsCount: 'منتج متاح', activeOffers: 'عروض نشطة', areas: 'منطقتان',
    allAreas: 'كل المناطق', inside: 'داخل المتجر', outside: 'المنطقة الخارجية',
    searchPlaceholder: 'ابحث عن منتج بالاسم...', categories: 'التصنيفات', allCategories: 'كل التصنيفات',
    showing: 'عرض', product: 'منتج', products: 'منتجات', noResults: 'لا توجد منتجات مطابقة',
    noResultsBody: 'جرّب تغيير البحث أو الفلاتر لرؤية المزيد من المنتجات.', clearFilters: 'مسح الفلاتر',
    inStock: 'متوفر', outOfStock: 'غير متوفر', offer: 'عرض', priceFrom: 'بدلاً من',
    lastUpdated: 'آخر تحديث', catalogNote: 'الأسعار بالجنيه المصري',
    staffEyebrow: 'مساحة آمنة للفريق', staffTitle: 'إدارة المتجر بوضوح', staffBody: 'تابع التوافر والأسعار والعروض في مكان واحد، وخلّي الكتالوج محدثاً دائماً.',
    nameLabel: 'البريد الإلكتروني', passcodeLabel: 'كلمة المرور', namePlaceholder: 'you@example.com', passcodePlaceholder: '••••••••', enterWorkspace: 'دخول إلى المساحة',
    loginHint: 'للتجربة: اكتب أي اسم ورمز من 4 أرقام أو أكثر.', authHint: 'استخدم بريد حساب Supabase وكلمة المرور الخاصة بك.', authMode: 'مصادقة Supabase', pendingAccess: 'الحساب في انتظار موافقة المالك.', authFailed: 'تعذر تسجيل الدخول. تحقق من البريد وكلمة المرور.', backToCatalog: 'العودة للكتالوج',
    dashboard: 'نظرة عامة', inventory: 'المخزون', signOut: 'تسجيل الخروج', viewCatalog: 'عرض الكتالوج',
    goodMorning: 'صباح الخير', workspaceSummary: 'هذه لقطة سريعة عن حالة منتجاتك الآن.',
    totalProducts: 'إجمالي المنتجات', availableNow: 'متوفر الآن', needRestock: 'يحتاج توريد', offers: 'عروض نشطة',
    latestActivity: 'آخر التحديثات', manageInventory: 'إدارة المخزون', manageInventoryBody: 'حدّث السعر أو التوافر أو العرض وسيظهر التعديل فوراً في الكتالوج.',
    addProduct: 'إضافة منتج', productName: 'اسم المنتج', category: 'التصنيف', area: 'المنطقة', price: 'السعر',
    compareAt: 'السعر السابق', optional: 'اختياري', imageStyle: 'شكل الصورة', availability: 'التوافر',
    saveProduct: 'حفظ المنتج', cancel: 'إلغاء', edit: 'تعديل', available: 'متوفر', unavailable: 'غير متوفر',
    insideShop: 'داخل المتجر', outsideArea: 'المنطقة الخارجية', searchInventory: 'ابحث في المخزون...',
    all: 'الكل', statusUpdated: 'تم تحديث الحالة', productSaved: 'تم حفظ المنتج', productAdded: 'تمت إضافة المنتج',
    emptyInventory: 'لا توجد منتجات بهذا البحث', liveSync: 'المزامنة مباشرة', demoMode: 'وضع العرض التجريبي',
    arabicName: 'الاسم بالعربية', englishName: 'الاسم بالإنجليزية', offerText: 'نص العرض', offerPlaceholder: 'مثال: عرض الأسبوع',
    noOffer: 'بدون عرض', removeOffer: 'إزالة العرض', close: 'إغلاق', quickAction: 'إجراء سريع',
    currentCatalog: 'في الكتالوج الآن', staffOnly: 'للموظفين فقط', footerNote: 'كتالوج للعرض فقط — لا يوجد طلب أو دفع أونلاين',
  },
  en: {
    catalog: 'Catalog', staffLogin: 'Staff login', staffWorkspace: 'Staff workspace',
    brandTagline: 'One store, everything close', heroTitle: 'Everyday picks, clearer and easier',
    heroBody: 'Browse products available inside the shop and in the outside area. Prices and availability are updated directly by our team.',
    browseCatalog: 'Browse products', updatedLive: 'Updated live', freshInventory: "Today's inventory", productsCount: 'products available', activeOffers: 'active offers', areas: 'two areas',
    allAreas: 'All areas', inside: 'Inside the shop', outside: 'Outside area',
    searchPlaceholder: 'Search products by name...', categories: 'Categories', allCategories: 'All categories',
    showing: 'Showing', product: 'product', products: 'products', noResults: 'No matching products',
    noResultsBody: 'Try changing your search or filters to see more products.', clearFilters: 'Clear filters',
    inStock: 'In stock', outOfStock: 'Out of stock', offer: 'Offer', priceFrom: 'from',
    lastUpdated: 'Last updated', catalogNote: 'Prices in Egyptian pounds',
    staffEyebrow: 'A focused space for your team', staffTitle: 'Run the store with clarity', staffBody: 'Keep availability, prices, and offers current from one calm workspace.',
    nameLabel: 'Email address', passcodeLabel: 'Password', namePlaceholder: 'you@example.com', passcodePlaceholder: '••••••••', enterWorkspace: 'Enter workspace',
    loginHint: 'Demo mode: use any name and a passcode with 4+ characters.', authHint: 'Use your Supabase account email and password.', authMode: 'Supabase Auth', pendingAccess: 'This account is waiting for owner approval.', authFailed: 'Sign in failed. Check your email and password.', backToCatalog: 'Back to catalog',
    dashboard: 'Overview', inventory: 'Inventory', signOut: 'Sign out', viewCatalog: 'View catalog',
    goodMorning: 'Good morning', workspaceSummary: "Here is a quick pulse on your products right now.",
    totalProducts: 'Total products', availableNow: 'Available now', needRestock: 'Needs restock', offers: 'Active offers',
    latestActivity: 'Latest activity', manageInventory: 'Manage inventory', manageInventoryBody: 'Update a price, availability, or offer and the catalog reflects it instantly.',
    addProduct: 'Add product', productName: 'Product name', category: 'Category', area: 'Area', price: 'Price',
    compareAt: 'Previous price', optional: 'optional', imageStyle: 'Image style', availability: 'Availability',
    saveProduct: 'Save product', cancel: 'Cancel', edit: 'Edit', available: 'In stock', unavailable: 'Out of stock',
    insideShop: 'Inside the shop', outsideArea: 'Outside area', searchInventory: 'Search inventory...',
    all: 'All', statusUpdated: 'Status updated', productSaved: 'Product saved', productAdded: 'Product added',
    emptyInventory: 'No products match this search', liveSync: 'Live sync', demoMode: 'Demo mode',
    arabicName: 'Arabic name', englishName: 'English name', offerText: 'Offer text', offerPlaceholder: 'Example: Weekly offer',
    noOffer: 'No offer', removeOffer: 'Remove offer', close: 'Close', quickAction: 'Quick action',
    currentCatalog: 'Live in catalog', staffOnly: 'Staff only', footerNote: 'View-only catalog — no online ordering or payment',
  },
} as const

export type CopyKey = keyof typeof COPY.ar
export const tr = (locale: Locale, key: CopyKey) => COPY[locale][key]
export const text = (locale: Locale, value: { ar: string; en: string }) => value[locale]

export function productSearchText(product: Product) {
  return [product.name.ar, product.name.en, product.category.label.ar, product.category.label.en].join(' ').toLocaleLowerCase()
}
