import { useEffect, useState } from 'react'
import { AREA_LABELS, CATEGORY_LABELS } from './data'
import { fetchRemoteProducts, isSupabaseConfigured, subscribeToRemoteProducts } from './supabase'
import { loadActivities, loadProducts, saveActivities, saveProducts, subscribeToProducts } from './storage'
import type { Activity, Area, CategoryId, Locale, Product } from './types'

export function formatMoney(value: number, locale: Locale) {
  return new Intl.NumberFormat(locale === 'ar' ? 'ar-EG' : 'en-EG', {
    style: 'currency', currency: 'EGP', maximumFractionDigits: 0,
  }).format(value)
}

export function formatTime(value: string, locale: Locale) {
  return new Intl.DateTimeFormat(locale === 'ar' ? 'ar-EG' : 'en-EG', {
    hour: 'numeric', minute: '2-digit', day: 'numeric', month: 'short',
  }).format(new Date(value))
}

export function areaLabel(area: Area, locale: Locale) { return AREA_LABELS[area][locale] }
export function categoryLabel(category: CategoryId, locale: Locale) { return CATEGORY_LABELS[category][locale] }

export function useCatalog() {
  const [products, setProducts] = useState<Product[]>(() => loadProducts())
  const [lastUpdated, setLastUpdated] = useState(() => new Date())

  useEffect(() => {
    let active = true
    if (isSupabaseConfigured) {
      void fetchRemoteProducts()
        .then((incoming) => {
          if (active) {
            setProducts(incoming.length > 0 ? incoming : loadProducts())
            setLastUpdated(new Date())
          }
        })
        .catch((error) => console.error('Supabase product load failed', error))
      const unsubscribe = subscribeToRemoteProducts((incoming) => {
        if (active) {
          setProducts(incoming.length > 0 ? incoming : loadProducts())
          setLastUpdated(new Date())
        }
      })
      return () => { active = false; unsubscribe() }
    }

    return subscribeToProducts((incoming) => {
      setProducts(incoming)
      setLastUpdated(new Date())
    })
  }, [])

  const commit = (next: Product[]) => {
    setProducts(next)
    setLastUpdated(new Date())
    if (!isSupabaseConfigured) saveProducts(next)
  }

  return { products, lastUpdated, commit }
}

export function useActivities() {
  const [activities, setActivities] = useState<Activity[]>(() => loadActivities())
  const addActivity = (activity: Activity) => {
    const next = [activity, ...activities].slice(0, 8)
    setActivities(next)
    saveActivities(next)
  }
  return { activities, addActivity }
}

export function makeActivity(action: Activity['action'], product: Product, detail: Activity['detail']): Activity {
  return { id: `activity-${Date.now()}`, action, productName: product.name, detail, at: new Date().toISOString() }
}

export function makeId() {
  return typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `product-${Date.now()}`
}
