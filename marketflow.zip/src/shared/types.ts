export type Locale = 'ar' | 'en'
export type Area = 'inside' | 'outside'
export type Availability = 'in_stock' | 'out_of_stock'
export type StaffRole = 'pending' | 'cashier' | 'owner'

export type CategoryId = 'produce' | 'dairy' | 'bakery' | 'pantry' | 'drinks' | 'snacks'

export interface LocalizedText {
  ar: string
  en: string
}

export interface Product {
  id: string
  name: LocalizedText
  category: { id: CategoryId; label: LocalizedText }
  area: Area
  price: number
  stock?: number
  compareAtPrice?: number
  availability: Availability
  image: string
  offer?: LocalizedText
  updatedAt: string
}

export interface StaffUser {
  id: string
  email: string
  fullName: string
  role: StaffRole
}

export interface UserAccount {
  id: string
  email: string
  fullName: string
  role: StaffRole
}

export interface Activity {
  id: string
  action: 'created' | 'updated' | 'availability'
  productName: LocalizedText
  detail: LocalizedText
  at: string
}
