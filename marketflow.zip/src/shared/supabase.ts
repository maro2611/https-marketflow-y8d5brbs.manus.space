import { createClient, type User } from '@supabase/supabase-js'
import { CATEGORY_LABELS } from './data'
import type { Area, Availability, CategoryId, Product, StaffRole, StaffUser, UserAccount } from './types'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined
const supabasePublishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined

export const isSupabaseConfigured = Boolean(supabaseUrl && supabasePublishableKey)

export const supabase = createClient(
  supabaseUrl ?? 'https://placeholder.supabase.co',
  supabasePublishableKey ?? 'placeholder-publishable-key',
)

type SupabaseProductRow = {
  id: number
  name: string
  name_ar?: string | null
  name_en?: string | null
  price: number | string
  stock: number | string
  area?: 'in' | 'out' | null
  category?: string | null
  active?: boolean | null
  updated_at?: string | null
  compare_at_price?: number | string | null
  offer_ar?: string | null
  offer_en?: string | null
  image_key?: string | null
}

function categoryId(value: string | null | undefined): CategoryId {
  return value && value in CATEGORY_LABELS ? value as CategoryId : 'produce'
}

export function mapSupabaseProduct(row: SupabaseProductRow): Product {
  const category = categoryId(row.category)
  const stock = Number(row.stock ?? 0)
  const offerAr = row.offer_ar?.trim() ?? ''
  const offerEn = row.offer_en?.trim() ?? ''
  return {
    id: String(row.id),
    name: { ar: row.name_ar || row.name, en: row.name_en || row.name_ar || row.name },
    category: { id: category, label: CATEGORY_LABELS[category] },
    area: row.area === 'out' ? 'outside' : 'inside',
    price: Number(row.price),
    stock,
    compareAtPrice: row.compare_at_price == null ? undefined : Number(row.compare_at_price),
    availability: stock > 0 ? 'in_stock' : 'out_of_stock',
    image: row.image_key || 'produce',
    offer: offerAr || offerEn ? { ar: offerAr, en: offerEn || offerAr } : undefined,
    updatedAt: row.updated_at || new Date().toISOString(),
  }
}

export async function fetchRemoteProducts() {
  const expanded = await supabase
    .from('products')
    .select('id,name,name_ar,name_en,price,stock,area,category,active,updated_at,compare_at_price,offer_ar,offer_en,image_key')
    .order('id', { ascending: false })

  if (!expanded.error) return (expanded.data as SupabaseProductRow[]).map(mapSupabaseProduct)

  const fallback = await supabase
    .from('products')
    .select('id,name,price,stock,active,updated_at')
    .order('id', { ascending: false })

  if (fallback.error) throw expanded.error
  return (fallback.data as SupabaseProductRow[]).map(mapSupabaseProduct)
}

export function subscribeToRemoteProducts(onProducts: (products: Product[]) => void) {
  const channel = supabase
    .channel('marketflow-products-live')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'products' }, () => {
      void fetchRemoteProducts().then(onProducts).catch((error) => console.error('Supabase Realtime reload failed', error))
    })
    .subscribe()

  return () => { void supabase.removeChannel(channel) }
}

function mapRole(value: string | null | undefined): StaffRole {
  return value === 'owner' || value === 'cashier' ? value : 'pending'
}

async function profileForUser(user: User): Promise<StaffUser> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, role')
    .eq('id', user.id)
    .single()

  if (error) throw error
  return {
    id: user.id,
    email: user.email || '',
    fullName: user.user_metadata?.full_name || user.email || '',
    role: mapRole(data.role),
  }
}

export async function getCurrentStaffUser() {
  const { data: { user } } = await supabase.auth.getUser()
  return user ? profileForUser(user) : null
}

export async function getCurrentAccount(): Promise<UserAccount | null> {
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return null
  const { error: syncError } = await supabase.rpc('sync_my_owner_role')
  if (syncError) console.warn('Optional owner role sync unavailable', syncError.message)
  try {
    return await profileForUser(user)
  } catch {
    return { id: user.id, email: user.email || '', fullName: user.user_metadata?.full_name || user.email || '', role: 'pending' }
  }
}

export async function signInAccount(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) throw error
  if (!data.user) throw new Error('No authenticated user returned')
  return getCurrentAccount()
}

export async function signUpAccount(email: string, password: string, fullName: string) {
  const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { full_name: fullName } } })
  if (error) throw error
  return { account: data.session ? await getCurrentAccount() : null, needsEmailConfirmation: !data.session }
}

export async function addOwnerEmail(email: string) {
  const { error } = await supabase.rpc('add_owner_email', { p_email: email.trim().toLowerCase() })
  if (error) throw error
}

export async function signInStaff(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) throw error
  if (!data.user) throw new Error('No authenticated user returned')
  const { error: syncError } = await supabase.rpc('sync_my_owner_role')
  if (syncError) console.warn('Owner role sync unavailable; using existing profile role', syncError.message)
  try {
    return await profileForUser(data.user)
  } catch {
    throw new Error('Your Supabase account has no readable profile. Run roles_and_optional_auth.sql, then sign in again.')
  }
}

export function subscribeToAuth(onUser: (user: UserAccount | null) => void) {
  const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
    if (!session) {
      onUser(null)
      return
    }
    window.setTimeout(() => {
      void getCurrentAccount().then(onUser).catch(() => onUser(null))
    }, 0)
  })
  return () => subscription.unsubscribe()
}

export async function signOutStaff() {
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

export async function updateProductStock(productId: string, stock: number) {
  const numericProductId = Number(productId)
  if (!isSupabaseConfigured || !Number.isSafeInteger(numericProductId) || numericProductId <= 0) {
    return { skipped: true as const }
  }

  const { error } = await supabase.rpc('update_product_stock', {
    p_product_id: numericProductId,
    p_stock: stock,
  })

  if (error) throw error
  return { skipped: false as const }
}

export async function createRemoteSale(items: Array<{ productId: string; quantity: number }>, paymentMethod: 'cash' | 'card', discount = 0) {
  if (!isSupabaseConfigured) return { skipped: true as const, invoice: null }
  const { data, error } = await supabase.rpc('create_sale', {
    p_items: items.map((item) => ({ product_id: Number(item.productId), quantity: item.quantity })),
    p_payment_method: paymentMethod,
    p_discount: discount,
  })
  if (error) throw error
  return { skipped: false as const, invoice: data }
}

export async function openRemoteShift(openingCash: number) {
  if (!isSupabaseConfigured) return { skipped: true as const, shift: null }
  const { data, error } = await supabase.rpc('open_shift', { p_opening_cash: openingCash })
  if (error) throw error
  return { skipped: false as const, shift: data }
}

export type RemoteShift = { id: number; opening_cash: number; counted_cash: number | null; expected_cash: number | null; difference: number | null; float_left: number | null; handed_over: number | null; status: 'open' | 'closed'; opened_at: string; closed_at: string | null }

export async function getOpenRemoteShift() {
  if (!isSupabaseConfigured) return null
  const { data, error } = await supabase.from('shifts').select('id,opening_cash,counted_cash,expected_cash,difference,float_left,handed_over,status,opened_at,closed_at').eq('cashier_id', (await supabase.auth.getUser()).data.user?.id || '').eq('status', 'open').maybeSingle()
  if (error) throw error
  return data as RemoteShift | null
}

export async function closeRemoteShift(shiftId: number, countedCash: number, floatLeft: number, note: string) {
  if (!isSupabaseConfigured) return { skipped: true as const, shift: null }
  const { data, error } = await supabase.rpc('close_shift', { p_shift_id: shiftId, p_counted_cash: countedCash, p_float_left: floatLeft, p_note: note || null })
  if (error) throw error
  return { skipped: false as const, shift: data as RemoteShift }
}

export type CashierRecord = { id: string; username: string; full_name: string; phone: string | null; status: 'active' | 'disabled' }

export async function manageCashier(action: 'list_cashiers' | 'create_cashier' | 'reset_password' | 'set_status' | 'rename' | 'delete', payload: Record<string, unknown> = {}) {
  if (!isSupabaseConfigured) return { ok: false, data: [] as CashierRecord[] }
  const { data, error } = await supabase.functions.invoke('staff-admin', { body: { action, ...payload } })
  if (error) throw error
  if (data?.error) throw new Error(data.error)
  return data as { ok?: boolean; data?: CashierRecord[]; id?: string; username?: string }
}

export async function fetchOwnerReport() {
  if (!isSupabaseConfigured) return { invoices: [] as Array<{ id: number; total: number; status: string; created_at: string }>, items: [] as Array<{ product_id: number; quantity: number }> }
  const [invoices, items] = await Promise.all([
    supabase.from('invoices').select('id,total,status,created_at').order('created_at', { ascending: false }).limit(500),
    supabase.from('invoice_items').select('product_id,quantity').limit(2000),
  ])
  if (invoices.error) throw invoices.error
  if (items.error) throw items.error
  return { invoices: invoices.data as Array<{ id: number; total: number; status: string; created_at: string }>, items: items.data as Array<{ product_id: number; quantity: number }> }
}

function baseProductPayload(product: Product) {
  return {
    name: product.name.ar || product.name.en,
    price: product.price,
    stock: product.stock ?? (product.availability === 'in_stock' ? 1 : 0),
  }
}

function expandedProductPayload(product: Product) {
  return {
    ...baseProductPayload(product),
    name_ar: product.name.ar,
    name_en: product.name.en,
    area: product.area === 'outside' ? 'out' : 'in',
    category: product.category.id,
    active: true,
    updated_at: new Date().toISOString(),
    compare_at_price: product.compareAtPrice ?? null,
    offer_ar: product.offer?.ar || null,
    offer_en: product.offer?.en || null,
    image_key: product.image,
  }
}

function isMissingColumnError(error: { code?: string; message?: string } | null) {
  return error?.code === '42703' || error?.code === 'PGRST204' || /column .* does not exist/i.test(error?.message || '')
}

export async function saveRemoteProduct(product: Product, isNew: boolean) {
  if (!isSupabaseConfigured) return { skipped: true as const, product }
  const numericProductId = Number(product.id)
  if (!isNew && (!Number.isSafeInteger(numericProductId) || numericProductId <= 0)) {
    return { skipped: true as const, product }
  }

  const persist = async (payload: ReturnType<typeof expandedProductPayload> | ReturnType<typeof baseProductPayload>) => {
    if (!isNew && Number.isSafeInteger(numericProductId) && numericProductId > 0) {
      const { data, error } = await supabase
        .from('products')
        .update(payload)
        .eq('id', numericProductId)
        .select('id,name,name_ar,name_en,price,stock,area,category,active,updated_at,compare_at_price,offer_ar,offer_en,image_key')
        .single()
      if (error) throw error
      return mapSupabaseProduct(data as SupabaseProductRow)
    }

      const { data, error } = await supabase
        .from('products')
        .insert(payload)
        .select('id,name,name_ar,name_en,price,stock,area,category,active,updated_at,compare_at_price,offer_ar,offer_en,image_key')
      .single()
    if (error) throw error
    return mapSupabaseProduct(data as SupabaseProductRow)
  }

  try {
    return { skipped: false as const, product: await persist(expandedProductPayload(product)) }
  } catch (error) {
    if (!isMissingColumnError(error as { code?: string; message?: string })) throw error
    return { skipped: false as const, product: await persist(baseProductPayload(product)) }
  }
}
