import { DEFAULT_ACTIVITIES, SEED_PRODUCTS } from './data'
import type { Activity, Locale, Product } from './types'

const PRODUCTS_KEY = 'marketflow-products-v1'
const LOCALE_KEY = 'marketflow-locale-v1'
const SESSION_KEY = 'marketflow-staff-session-v1'
const ACTIVITIES_KEY = 'marketflow-activities-v1'
const CHANNEL_NAME = 'marketflow-catalog-sync'

type CatalogMessage = { type: 'catalog-update'; products: Product[] }

export function loadProducts(): Product[] {
  try {
    const value = localStorage.getItem(PRODUCTS_KEY)
    if (!value) return SEED_PRODUCTS
    const parsed = JSON.parse(value) as Product[]
    return Array.isArray(parsed) && parsed.length ? parsed : SEED_PRODUCTS
  } catch {
    return SEED_PRODUCTS
  }
}

export function saveProducts(products: Product[]) {
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products))
  window.dispatchEvent(new CustomEvent('marketflow-catalog-updated', { detail: products }))
  if ('BroadcastChannel' in window) {
    const channel = new BroadcastChannel(CHANNEL_NAME)
    channel.postMessage({ type: 'catalog-update', products } satisfies CatalogMessage)
    channel.close()
  }
}

export function subscribeToProducts(onUpdate: (products: Product[]) => void) {
  const customHandler = (event: Event) => {
    const products = (event as CustomEvent<Product[]>).detail
    if (Array.isArray(products)) onUpdate(products)
  }
  const storageHandler = (event: StorageEvent) => {
    if (event.key !== PRODUCTS_KEY || !event.newValue) return
    try {
      const products = JSON.parse(event.newValue) as Product[]
      if (Array.isArray(products)) onUpdate(products)
    } catch { /* ignore malformed external values */ }
  }
  window.addEventListener('marketflow-catalog-updated', customHandler)
  window.addEventListener('storage', storageHandler)
  const channel = 'BroadcastChannel' in window ? new BroadcastChannel(CHANNEL_NAME) : null
  if (channel) {
    channel.onmessage = (event: MessageEvent<CatalogMessage>) => {
      if (event.data?.type === 'catalog-update' && Array.isArray(event.data.products)) onUpdate(event.data.products)
    }
  }
  return () => {
    window.removeEventListener('marketflow-catalog-updated', customHandler)
    window.removeEventListener('storage', storageHandler)
    channel?.close()
  }
}

export function loadLocale(): Locale {
  const value = localStorage.getItem(LOCALE_KEY)
  return value === 'en' ? 'en' : 'ar'
}

export function saveLocale(locale: Locale) {
  localStorage.setItem(LOCALE_KEY, locale)
}

export function loadSession(): { name: string } | null {
  try {
    const value = localStorage.getItem(SESSION_KEY)
    return value ? JSON.parse(value) as { name: string } : null
  } catch { return null }
}

export function saveSession(session: { name: string }) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(session))
}

export function clearSession() {
  localStorage.removeItem(SESSION_KEY)
}

export function loadActivities(): Activity[] {
  try {
    const value = localStorage.getItem(ACTIVITIES_KEY)
    return value ? JSON.parse(value) as Activity[] : DEFAULT_ACTIVITIES
  } catch { return DEFAULT_ACTIVITIES }
}

export function saveActivities(activities: Activity[]) {
  localStorage.setItem(ACTIVITIES_KEY, JSON.stringify(activities.slice(0, 8)))
}
