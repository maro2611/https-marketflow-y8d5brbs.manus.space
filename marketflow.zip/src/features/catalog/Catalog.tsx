import { useMemo, useState } from 'react'
import { ArrowLeft, ArrowRight, ArrowUpRight, CircleCheck, CircleX, Globe2, Leaf, MapPin, Package, Search, Sparkles, Store, UserRound } from 'lucide-react'
import { AREA_LABELS, CATEGORY_LABELS, CATEGORY_ORDER, PRODUCT_VISUALS } from '../../shared/data'
import { productSearchText, tr, text } from '../../shared/i18n'
import { areaLabel, categoryLabel, formatMoney } from '../../shared/utils'
import type { Area, CategoryId, Locale, Product } from '../../shared/types'

interface CatalogProps {
  locale: Locale
  products: Product[]
  lastUpdated: Date
  onLocaleChange: (locale: Locale) => void
  onNavigate: (path: string) => void
}

type AreaFilter = 'all' | Area

function LogoMark() {
  return <span className="logo-mark" aria-hidden="true"><Leaf size={20} strokeWidth={2.4} /></span>
}

function LocaleToggle({ locale, onLocaleChange }: Pick<CatalogProps, 'locale' | 'onLocaleChange'>) {
  return <button className="locale-toggle" type="button" onClick={() => onLocaleChange(locale === 'ar' ? 'en' : 'ar')} aria-label={locale === 'ar' ? 'Switch to English' : 'التبديل إلى العربية'}>
    <Globe2 size={16} />
    <span>{locale === 'ar' ? 'English' : 'العربية'}</span>
  </button>
}

function ProductVisual({ product }: { product: Product }) {
  const visual = PRODUCT_VISUALS[product.image] ?? PRODUCT_VISUALS.produce
  return <div className={`product-visual ${visual.tone}`} aria-hidden="true">
    <span className="visual-orbit orbit-one" />
    <span className="visual-orbit orbit-two" />
    <span className="visual-emoji">{visual.emoji}</span>
    <span className="visual-shelf" />
  </div>
}

function ProductCard({ product, locale }: { product: Product; locale: Locale }) {
  const isInStock = product.availability === 'in_stock'
  const discount = product.compareAtPrice ? Math.round((1 - product.price / product.compareAtPrice) * 100) : 0
  return <article className={`product-card ${!isInStock ? 'is-out' : ''}`}>
    <div className="product-card-visual-wrap">
      <ProductVisual product={product} />
      {product.offer && <span className="offer-pill"><Sparkles size={12} />{text(locale, product.offer)}</span>}
      {!isInStock && <span className="out-stock-overlay"><CircleX size={15} />{tr(locale, 'outOfStock')}</span>}
    </div>
    <div className="product-card-body">
      <div className="product-card-meta"><span>{text(locale, product.category.label)}</span><span className="meta-dot" />{areaLabel(product.area, locale)}</div>
      <h3>{text(locale, product.name)}</h3>
      <div className="product-card-footer">
        <div className="price-stack">
          <strong>{formatMoney(product.price, locale)}</strong>
          {product.compareAtPrice && <span>{tr(locale, 'priceFrom')} {formatMoney(product.compareAtPrice, locale)}</span>}
        </div>
        <span className={`stock-status ${isInStock ? 'stock-yes' : 'stock-no'}`}>
          {isInStock ? <CircleCheck size={14} /> : <CircleX size={14} />}
          {isInStock ? tr(locale, 'inStock') : tr(locale, 'outOfStock')}
        </span>
      </div>
      {discount > 0 && <span className="discount-note">-{discount}%</span>}
    </div>
  </article>
}

function AreaFilter({ active, locale, onChange }: { active: AreaFilter; locale: Locale; onChange: (value: AreaFilter) => void }) {
  const areas: { id: AreaFilter; label: string; icon: typeof Store }[] = [
    { id: 'all', label: tr(locale, 'allAreas'), icon: Package },
    { id: 'inside', label: AREA_LABELS.inside[locale], icon: Store },
    { id: 'outside', label: AREA_LABELS.outside[locale], icon: MapPin },
  ]
  return <div className="area-filter" role="tablist" aria-label={tr(locale, 'areas')}>
    {areas.map(({ id, label, icon: Icon }) => <button key={id} type="button" role="tab" aria-selected={active === id} className={active === id ? 'active' : ''} onClick={() => onChange(id)}>
      <Icon size={16} /> <span>{label}</span>
    </button>)}
  </div>
}

export function Catalog({ locale, products, lastUpdated, onLocaleChange, onNavigate }: CatalogProps) {
  const [search, setSearch] = useState('')
  const [area, setArea] = useState<AreaFilter>('all')
  const [category, setCategory] = useState<CategoryId | 'all'>('all')
  const [showFilters, setShowFilters] = useState(false)

  const filteredProducts = useMemo(() => products.filter((product) => {
    const matchesArea = area === 'all' || product.area === area
    const matchesCategory = category === 'all' || product.category.id === category
    const matchesSearch = !search.trim() || productSearchText(product).includes(search.trim().toLocaleLowerCase())
    return matchesArea && matchesCategory && matchesSearch
  }), [area, category, products, search])

  const offersCount = products.filter((product) => product.offer && product.availability === 'in_stock').length
  const lastUpdatedLabel = new Intl.DateTimeFormat(locale === 'ar' ? 'ar-EG' : 'en-EG', { hour: 'numeric', minute: '2-digit' }).format(lastUpdated)

  return <div className="catalog-page">
    <header className="site-header container-wide">
      <button type="button" className="brand-button" onClick={() => onNavigate('/')} aria-label="MarketFlow home">
        <LogoMark />
        <span className="brand-copy"><strong>MarketFlow</strong><small>{tr(locale, 'brandTagline')}</small></span>
      </button>
      <div className="header-actions">
        <span className="header-live"><span className="live-dot" />{tr(locale, 'updatedLive')}</span>
        <LocaleToggle locale={locale} onLocaleChange={onLocaleChange} />
        <button className="account-link" type="button" onClick={() => onNavigate('/login')}><UserRound size={14} />{locale === 'ar' ? 'تسجيل الدخول' : 'Sign in'}</button><button className="staff-link" type="button" onClick={() => onNavigate('/staff/login')}><LockIcon />{tr(locale, 'staffLogin')}</button>
      </div>
    </header>

    <main>
      <section className="catalog-hero container-wide">
        <div className="hero-copy">
          <div className="eyebrow"><span className="eyebrow-line" />{tr(locale, 'brandTagline')}<Sparkles size={15} /></div>
          <h1>{tr(locale, 'heroTitle')}</h1>
          <p>{tr(locale, 'heroBody')}</p>
          <div className="hero-actions">
            <a className="primary-button" href="#catalog-grid"><span>{tr(locale, 'browseCatalog')}</span><ArrowLeft size={17} /></a>
            <span className="updated-note"><RefreshIcon />{tr(locale, 'lastUpdated')} {lastUpdatedLabel}</span>
          </div>
        </div>
        <div className="hero-visual" aria-label={tr(locale, 'freshInventory')}>
          <div className="hero-blob blob-green" />
          <div className="hero-blob blob-gold" />
          <div className="hero-blob blob-cream" />
          <div className="hero-basket"><span>🥬</span><span>🍊</span><span>🥖</span></div>
          <div className="hero-badge badge-top"><Leaf size={16} />{tr(locale, 'freshInventory')}</div>
          <div className="hero-badge badge-bottom"><span className="live-dot" />{products.length} {tr(locale, 'productsCount')}</div>
        </div>
      </section>

      <section className="stats-strip container-wide" aria-label={tr(locale, 'catalog')}>
        <div className="mini-stat"><span className="mini-stat-icon green"><Package size={17} /></span><span><strong>{products.length}</strong><small>{tr(locale, 'productsCount')}</small></span></div>
        <div className="mini-stat"><span className="mini-stat-icon gold"><Sparkles size={17} /></span><span><strong>{offersCount}</strong><small>{tr(locale, 'activeOffers')}</small></span></div>
        <div className="mini-stat"><span className="mini-stat-icon blue"><Store size={17} /></span><span><strong>2</strong><small>{tr(locale, 'areas')}</small></span></div>
        <div className="mini-stat stat-note"><span className="live-dot" /><span><strong>{tr(locale, 'updatedLive')}</strong><small>{tr(locale, 'catalogNote')}</small></span></div>
      </section>

      <section className="catalog-section container-wide" id="catalog-grid">
        <div className="section-heading">
          <div><div className="eyebrow muted"><span className="eyebrow-line" />{tr(locale, 'catalog')}</div><h2>{tr(locale, 'freshInventory')}</h2></div>
          <button className="filter-toggle" type="button" onClick={() => setShowFilters((value) => !value)}><Search size={16} />{showFilters ? tr(locale, 'close') : tr(locale, 'categories')}</button>
        </div>
        <div className={`catalog-controls ${showFilters ? 'show-mobile' : ''}`}>
          <AreaFilter active={area} locale={locale} onChange={setArea} />
          <div className="search-field"><Search size={18} /><input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder={tr(locale, 'searchPlaceholder')} aria-label={tr(locale, 'searchPlaceholder')} /></div>
        </div>
        <div className="category-row" aria-label={tr(locale, 'categories')}>
          <button type="button" className={category === 'all' ? 'active' : ''} onClick={() => setCategory('all')}>{tr(locale, 'allCategories')}</button>
          {CATEGORY_ORDER.map((item) => <button type="button" key={item} className={category === item ? 'active' : ''} onClick={() => setCategory(item)}>{CATEGORY_LABELS[item][locale]}</button>)}
        </div>
        <div className="results-row"><span>{tr(locale, 'showing')} <strong>{filteredProducts.length}</strong> {filteredProducts.length === 1 ? tr(locale, 'product') : tr(locale, 'products')}</span><span className="results-area"><MapPin size={14} />{area === 'all' ? tr(locale, 'allAreas') : areaLabel(area, locale)}</span></div>
        {filteredProducts.length > 0 ? <div className="product-grid">{filteredProducts.map((product) => <ProductCard key={product.id} product={product} locale={locale} />)}</div> : <div className="empty-state"><span className="empty-icon"><Search size={24} /></span><h3>{tr(locale, 'noResults')}</h3><p>{tr(locale, 'noResultsBody')}</p><button type="button" className="secondary-button" onClick={() => { setSearch(''); setArea('all'); setCategory('all') }}>{tr(locale, 'clearFilters')}</button></div>}
      </section>
    </main>
    <footer className="site-footer container-wide"><span>© 2026 MarketFlow</span><span>{tr(locale, 'footerNote')}</span><button type="button" onClick={() => onNavigate('/staff/login')}>{tr(locale, 'staffOnly')} <ArrowUpRight size={13} /></button></footer>
  </div>
}

function LockIcon() { return <span className="lock-icon" aria-hidden="true">•</span> }
function RefreshIcon() { return <span className="refresh-icon" aria-hidden="true">↻</span> }
