import { FormEvent, useEffect, useMemo, useState } from 'react'
import { ArrowLeft, ArrowRight, Banknote, Check, CircleAlert, CircleCheck, CircleX, Clock3, CreditCard, Edit3, FileDown, FileSpreadsheet, Filter, Globe2, LayoutDashboard, LogOut, Mail, MapPin, Package, Plus, Printer, Search, ShieldCheck, ShoppingCart, Sparkles, Store, Tag, TrendingUp, X } from 'lucide-react'
import { jsPDF } from 'jspdf'
import { AREA_LABELS, CATEGORY_LABELS, CATEGORY_ORDER, PRODUCT_VISUALS } from '../../shared/data'
import { tr, text } from '../../shared/i18n'
import { clearSession, saveSession } from '../../shared/storage'
import { closeRemoteShift, createRemoteSale, fetchOwnerReport, getOpenRemoteShift, manageCashier, openRemoteShift, saveRemoteProduct, updateProductStock, type CashierRecord, type RemoteShift } from '../../shared/supabase'
import { areaLabel, categoryLabel, formatMoney, formatTime, makeActivity, makeId } from '../../shared/utils'
import type { Activity, Area, Availability, CategoryId, Locale, Product, StaffRole } from '../../shared/types'

interface StaffBaseProps {
  locale: Locale
  onLocaleChange: (locale: Locale) => void
  onNavigate: (path: string) => void
}

interface StaffLoginProps extends StaffBaseProps { onLoggedIn: (name: string) => void }

function LegacyStaffLogin({ locale, onLocaleChange, onNavigate, onLoggedIn }: StaffLoginProps) {
  const [name, setName] = useState('')
  const [passcode, setPasscode] = useState('')
  const [error, setError] = useState('')
  const submit = (event: FormEvent) => {
    event.preventDefault()
    if (name.trim().length < 2 || passcode.trim().length < 4) {
      setError(locale === 'ar' ? 'اكتب اسماً صحيحاً ورمز دخول من ٤ أحرف على الأقل.' : 'Enter a name and a passcode with at least 4 characters.')
      return
    }
    saveSession({ name: name.trim() })
    onLoggedIn(name.trim())
  }
  return <div className="staff-login-page">
    <header className="staff-login-header container-wide"><button type="button" className="brand-button" onClick={() => onNavigate('/')}><span className="logo-mark"><Store size={19} /></span><span className="brand-copy"><strong>MarketFlow</strong><small>{tr(locale, 'staffWorkspace')}</small></span></button><div className="header-actions"><button className="catalog-back" type="button" onClick={() => onNavigate('/')}><ArrowRight size={16} />{tr(locale, 'backToCatalog')}</button><LocaleToggle locale={locale} onLocaleChange={onLocaleChange} /></div></header>
    <main className="login-layout container-wide">
      <section className="login-intro"><span className="intro-kicker"><ShieldCheck size={16} />{tr(locale, 'staffEyebrow')}</span><h1>{tr(locale, 'staffTitle')}</h1><p>{tr(locale, 'staffBody')}</p><div className="login-illustration"><div className="login-circle circle-one" /><div className="login-circle circle-two" /><div className="login-card-stack"><div className="stack-card"><div className="stack-card-top"><span className="mini-logo"><LeafIcon /></span><span className="stack-dots">•••</span></div><strong>{locale === 'ar' ? 'كل شيء محدث' : 'Everything current'}</strong><span className="stack-line" /><span className="stack-line short" /></div><div className="stack-pill"><CircleCheck size={16} />{tr(locale, 'liveSync')}</div></div></div></section>
      <section className="login-panel"><div className="login-panel-head"><span className="panel-icon"><ShieldCheck size={20} /></span><div><span className="eyebrow muted">{tr(locale, 'staffLogin')}</span><h2>{locale === 'ar' ? 'مرحباً بفريقك' : 'Welcome, team'}</h2></div></div><form onSubmit={submit} className="staff-form"><label>{tr(locale, 'nameLabel')}<input value={name} onChange={(event) => setName(event.target.value)} placeholder={tr(locale, 'namePlaceholder')} autoComplete="name" /></label><label>{tr(locale, 'passcodeLabel')}<input value={passcode} onChange={(event) => setPasscode(event.target.value)} placeholder={tr(locale, 'passcodePlaceholder')} type="password" autoComplete="current-password" /></label>{error && <p className="form-error"><CircleAlert size={15} />{error}</p>}<button className="primary-button full" type="submit">{tr(locale, 'enterWorkspace')}<ArrowLeft size={17} /></button></form><p className="login-hint"><Sparkles size={14} />{tr(locale, 'loginHint')}</p><div className="demo-badge"><span className="live-dot" />{tr(locale, 'demoMode')}</div></section>
    </main>
  </div>
  }

interface RemoteStaffLoginProps extends StaffBaseProps {
  onLoggedIn: (email: string, password: string) => Promise<void>
  remoteMode: boolean
  initialError?: string
}

export function StaffLogin({ locale, onLocaleChange, onNavigate, onLoggedIn, remoteMode, initialError }: RemoteStaffLoginProps) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(initialError || '')
  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if (!email.trim() || password.trim().length < (remoteMode ? 6 : 4)) {
      setError(remoteMode ? (locale === 'ar' ? 'اكتب بريدك الإلكتروني وكلمة مرور صحيحة.' : 'Enter a valid email and password.') : (locale === 'ar' ? 'اكتب اسماً صحيحاً ورمز دخول من ٤ أحرف على الأقل.' : 'Enter a name and a passcode with at least 4 characters.'))
      return
    }
    try {
      await onLoggedIn(email.trim(), password)
    } catch (reason) {
      setError(reason instanceof Error && reason.message === 'pending' ? tr(locale, 'pendingAccess') : (reason instanceof Error ? reason.message : tr(locale, 'authFailed')))
    }
  }
  return <div className="staff-login-page">
    <header className="staff-login-header container-wide"><button type="button" className="brand-button" onClick={() => onNavigate('/')}><span className="logo-mark"><Store size={19} /></span><span className="brand-copy"><strong>MarketFlow</strong><small>{tr(locale, 'staffWorkspace')}</small></span></button><div className="header-actions"><button className="catalog-back" type="button" onClick={() => onNavigate('/')}><ArrowRight size={16} />{tr(locale, 'backToCatalog')}</button><LocaleToggle locale={locale} onLocaleChange={onLocaleChange} /></div></header>
    <main className="login-layout container-wide">
      <section className="login-intro"><span className="intro-kicker"><ShieldCheck size={16} />{tr(locale, 'staffEyebrow')}</span><h1>{tr(locale, 'staffTitle')}</h1><p>{tr(locale, 'staffBody')}</p><div className="login-illustration"><div className="login-circle circle-one" /><div className="login-circle circle-two" /><div className="login-card-stack"><div className="stack-card"><div className="stack-card-top"><span className="mini-logo"><LeafIcon /></span><span className="stack-dots">•••</span></div><strong>{locale === 'ar' ? 'كل شيء محدث' : 'Everything current'}</strong><span className="stack-line" /><span className="stack-line short" /></div><div className="stack-pill"><CircleCheck size={16} />{tr(locale, 'liveSync')}</div></div></div></section>
      <section className="login-panel"><div className="login-panel-head"><span className="panel-icon"><ShieldCheck size={20} /></span><div><span className="eyebrow muted">{tr(locale, 'staffLogin')}</span><h2>{locale === 'ar' ? 'مرحباً بفريقك' : 'Welcome, team'}</h2></div></div><form onSubmit={submit} className="staff-form"><label>{tr(locale, 'nameLabel')}<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder={tr(locale, 'namePlaceholder')} autoComplete="username" dir="ltr" /></label><label>{tr(locale, 'passcodeLabel')}<input required value={password} onChange={(event) => setPassword(event.target.value)} placeholder={tr(locale, 'passcodePlaceholder')} type="password" autoComplete="current-password" /></label>{error && <p className="form-error"><CircleAlert size={15} />{error}</p>}<button className="primary-button full" type="submit">{tr(locale, 'enterWorkspace')}<ArrowLeft size={17} /></button></form><p className="login-hint"><Sparkles size={14} />{tr(locale, remoteMode ? 'authHint' : 'loginHint')}</p><div className="demo-badge"><span className="live-dot" />{tr(locale, remoteMode ? 'authMode' : 'demoMode')}</div></section>
    </main>
  </div>
}

function LocaleToggle({ locale, onLocaleChange }: Pick<StaffBaseProps, 'locale' | 'onLocaleChange'>) {
  return <button className="locale-toggle" type="button" onClick={() => onLocaleChange(locale === 'ar' ? 'en' : 'ar')}><Globe2 size={16} />{locale === 'ar' ? 'English' : 'العربية'}</button>
}
function LeafIcon() { return <span aria-hidden="true">✦</span> }

interface StaffConsoleProps extends StaffBaseProps {
  userName: string
  role: StaffRole
  products: Product[]
  activities: Activity[]
  lastUpdated: Date
  commit: (products: Product[]) => void
  addActivity: (activity: Activity) => void
  onSignOut: () => void
  remoteMode: boolean
  onAddOwnerEmail: (email: string) => Promise<void>
}

export function StaffConsole({ locale, onLocaleChange, onNavigate, userName, role, products, activities, lastUpdated, commit, addActivity, onSignOut, remoteMode, onAddOwnerEmail }: StaffConsoleProps) {
  const [activeView, setActiveView] = useState<'overview' | 'inventory' | 'pos' | 'shifts' | 'staff' | 'reports'>(role === 'cashier' ? 'pos' : 'overview')
  const [search, setSearch] = useState('')
  const [area, setArea] = useState<'all' | Area>('all')
  const [category, setCategory] = useState<CategoryId | 'all'>('all')
  const [editor, setEditor] = useState<{ product?: Product } | null>(null)
  const [toast, setToast] = useState('')
  const [busyProductId, setBusyProductId] = useState<string | null>(null)
  const availableCount = products.filter((product) => product.availability === 'in_stock').length
  const offerCount = products.filter((product) => product.offer).length
  const filtered = useMemo(() => products.filter((product) => {
    const haystack = `${product.name.ar} ${product.name.en} ${product.category.label.ar} ${product.category.label.en}`.toLocaleLowerCase()
    return (!search || haystack.includes(search.toLocaleLowerCase())) && (area === 'all' || product.area === area) && (category === 'all' || product.category.id === category)
  }), [area, category, products, search])

  const showToast = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 2500) }
  const saveProduct = async (draft: Product, isNew: boolean) => {
    if (remoteMode && role !== 'owner') {
      showToast(locale === 'ar' ? 'هذه العملية متاحة للمالك فقط.' : 'Only the owner can manage product details.')
      return
    }
    try {
      const persisted = await saveRemoteProduct(draft, isNew)
      const savedDraft = persisted.product
      const next = isNew ? [savedDraft, ...products] : products.map((product) => product.id === savedDraft.id ? savedDraft : product)
      commit(next)
      addActivity(makeActivity(isNew ? 'created' : savedDraft.availability !== editor?.product?.availability ? 'availability' : 'updated', savedDraft, isNew ? { ar: 'تمت إضافة منتج جديد', en: 'New product added' } : { ar: 'تم تحديث بيانات المنتج', en: 'Product details updated' }))
      setEditor(null)
      showToast(isNew ? tr(locale, 'productAdded') : tr(locale, 'productSaved'))
    } catch {
      showToast(locale === 'ar' ? 'تعذر حفظ المنتج في Supabase.' : 'Supabase could not save this product.')
    }
  }
  const handleStockToggle = async (product: Product) => {
    if (busyProductId) return
    const nextAvailability: Availability = product.availability === 'in_stock' ? 'out_of_stock' : 'in_stock'
    setBusyProductId(product.id)
    try {
      await updateProductStock(product.id, nextAvailability === 'in_stock' ? 1 : 0)
      const updatedProduct = { ...product, availability: nextAvailability, stock: nextAvailability === 'in_stock' ? Math.max(product.stock ?? 0, 1) : 0, updatedAt: new Date().toISOString() }
      commit(products.map((item) => item.id === product.id ? updatedProduct : item))
      addActivity(makeActivity('availability', updatedProduct, { ar: 'تم تحديث حالة المخزون', en: 'Stock availability updated' }))
      showToast(locale === 'ar' ? 'تم تحديث المخزون بنجاح.' : 'Stock updated successfully.')
    } catch {
      showToast(locale === 'ar' ? 'تعذر تحديث المخزون في Supabase.' : 'Supabase stock update failed.')
    } finally {
      setBusyProductId(null)
    }
  }

  return <div className="staff-shell">
    <aside className="staff-sidebar"><button type="button" className="brand-button sidebar-brand" onClick={() => onNavigate('/')}><span className="logo-mark"><Store size={19} /></span><span className="brand-copy"><strong>MarketFlow</strong><small>{tr(locale, 'staffWorkspace')}</small></span></button><div className="sidebar-nav"><span className="sidebar-label">{locale === 'ar' ? 'المساحة' : 'Workspace'}</span><button type="button" className={activeView === 'pos' ? 'active' : ''} onClick={() => setActiveView('pos')}><ShoppingCart size={17} />{locale === 'ar' ? 'نقطة البيع' : 'POS'}</button><button type="button" className={activeView === 'shifts' ? 'active' : ''} onClick={() => setActiveView('shifts')}><Clock3 size={17} />{locale === 'ar' ? 'الورديات' : 'Shifts'}</button>{role === 'owner' && <><button type="button" className={activeView === 'overview' ? 'active' : ''} onClick={() => setActiveView('overview')}><LayoutDashboard size={17} />{tr(locale, 'dashboard')}</button><button type="button" className={activeView === 'reports' ? 'active' : ''} onClick={() => setActiveView('reports')}><TrendingUp size={17} />{locale === 'ar' ? 'التقارير' : 'Reports'}</button><button type="button" className={activeView === 'staff' ? 'active' : ''} onClick={() => setActiveView('staff')}><ShieldCheck size={17} />{locale === 'ar' ? 'الموظفون' : 'Staff'}</button></>}<button type="button" className={activeView === 'inventory' ? 'active' : ''} onClick={() => setActiveView('inventory')}><Package size={17} />{tr(locale, 'inventory')}<span className="nav-count">{products.length}</span></button></div><div className="sidebar-bottom"><div className="sync-card"><span className="sync-icon"><CircleCheck size={16} /></span><span><strong>{tr(locale, 'liveSync')}</strong><small>{tr(locale, 'currentCatalog')}</small></span></div><button className="sidebar-signout" type="button" onClick={onSignOut}><LogOut size={16} />{tr(locale, 'signOut')}</button></div></aside>
    <main className="staff-main"><header className="staff-topbar"><div className="mobile-brand"><span className="logo-mark"><Store size={17} /></span><strong>MarketFlow</strong></div><div className="staff-top-actions"><span className="staff-user"><span className="avatar">{userName.slice(0, 1).toUpperCase()}</span><span><strong>{userName}</strong><small>{role === 'owner' ? (locale === 'ar' ? 'مالك النظام' : 'Owner') : (locale === 'ar' ? 'كاشير' : 'Cashier')}</small></span></span><LocaleToggle locale={locale} onLocaleChange={onLocaleChange} /><button className="catalog-back" type="button" onClick={() => onNavigate('/')}><Store size={16} />{tr(locale, 'viewCatalog')}</button></div></header><div className="staff-content">
      {activeView !== 'pos' && activeView !== 'shifts' && activeView !== 'staff' && activeView !== 'reports' && <><div className="staff-heading"><div><span className="eyebrow muted"><span className="eyebrow-line" />{activeView === 'inventory' ? tr(locale, 'inventory') : tr(locale, 'dashboard')}</span><h1>{tr(locale, 'goodMorning')}, {userName.split(' ')[0]}</h1><p>{tr(locale, 'workspaceSummary')}</p></div>{role === 'owner' && <button className="primary-button" type="button" onClick={() => setEditor({})}><Plus size={17} />{tr(locale, 'addProduct')}</button>}</div><div className="dashboard-cards"><MetricCard icon={<Package size={19} />} tone="green" value={products.length} label={tr(locale, 'totalProducts')} trend="+2.4%" /><MetricCard icon={<CircleCheck size={19} />} tone="mint" value={availableCount} label={tr(locale, 'availableNow')} trend={`${Math.round((availableCount / Math.max(products.length, 1)) * 100)}%`} /><MetricCard icon={<CircleAlert size={19} />} tone="gold" value={products.length - availableCount} label={tr(locale, 'needRestock')} trend={tr(locale, 'outOfStock')} /><MetricCard icon={<Tag size={19} />} tone="blue" value={offerCount} label={tr(locale, 'offers')} trend={tr(locale, 'updatedLive')} /></div></>}
      {activeView === 'pos' ? <PosView locale={locale} products={products} onSaleComplete={(sold) => commit(products.map((product) => { const item = sold.find((entry) => entry.productId === product.id); return item ? { ...product, stock: Math.max(0, (product.stock ?? 0) - item.quantity), availability: (product.stock ?? 0) - item.quantity > 0 ? 'in_stock' : 'out_of_stock', updatedAt: new Date().toISOString() } : product }))} /> : activeView === 'shifts' ? <ShiftView locale={locale} role={role} /> : activeView === 'staff' ? <StaffManagementView locale={locale} /> : activeView === 'reports' ? <ReportsView locale={locale} products={products} /> : activeView === 'overview' ? <>{<Overview locale={locale} products={products} activities={activities} onManage={() => setActiveView('inventory')} />}{role === 'owner' && <OwnerInvite locale={locale} onAddOwnerEmail={onAddOwnerEmail} />}</> : <InventoryView locale={locale} products={filtered} search={search} setSearch={setSearch} area={area} setArea={setArea} category={category} setCategory={setCategory} onEdit={role === 'owner' ? (product) => setEditor({ product }) : undefined} onToggle={(product) => { void handleStockToggle(product) }} />}
      <div className="staff-footer-note"><span><span className="live-dot" />{tr(locale, 'liveSync')}</span><span>{tr(locale, 'lastUpdated')}: {formatTime(lastUpdated.toISOString(), locale)}</span></div>
    </div></main>
    {editor !== null && <ProductEditor locale={locale} product={editor.product} onCancel={() => setEditor(null)} onSave={saveProduct} />}
    {toast && <div className="toast"><CircleCheck size={16} />{toast}</div>}
  </div>
}

function ReportsView({ locale, products }: { locale: Locale; products: Product[] }) {
  const [report, setReport] = useState<{ invoices: Array<{ id: number; total: number; status: string; created_at: string }>; items: Array<{ product_id: number; quantity: number }> } | null>(null)
  const [error, setError] = useState('')
  useEffect(() => { void fetchOwnerReport().then(setReport).catch((reason: unknown) => setError(reason instanceof Error ? reason.message : (locale === 'ar' ? 'تعذر تحميل التقرير.' : 'Could not load report.'))) }, [locale])
  const completed = report?.invoices.filter((invoice) => invoice.status === 'completed') || []
  const today = new Date().toISOString().slice(0, 10)
  const todaySales = completed.filter((invoice) => invoice.created_at.slice(0, 10) === today).reduce((sum, invoice) => sum + Number(invoice.total), 0)
  const totalSales = completed.reduce((sum, invoice) => sum + Number(invoice.total), 0)
  const best = new Map<number, number>()
  report?.items.forEach((item) => best.set(item.product_id, (best.get(item.product_id) || 0) + Number(item.quantity)))
  const bestRows = [...best.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5)
  const exportExcel = () => { if (!report) return; const invoiceRows = completed.map((invoice) => `<tr><td>${invoice.id}</td><td>${Number(invoice.total).toFixed(2)}</td><td>${invoice.status}</td><td>${invoice.created_at}</td></tr>`).join(''); const bestSheet = bestRows.map(([productId, quantity]) => `<tr><td>${products.find((item) => Number(item.id) === productId)?.name.en || `#${productId}`}</td><td>${quantity}</td></tr>`).join(''); const html = `<html><head><meta charset="utf-8"></head><body><h1>MarketFlow Sales Report</h1><h2>Invoices</h2><table border="1"><tr><th>Invoice</th><th>Total EGP</th><th>Status</th><th>Created At</th></tr>${invoiceRows}</table><h2>Best Sellers</h2><table border="1"><tr><th>Product</th><th>Units Sold</th></tr>${bestSheet}</table></body></html>`; const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8' }); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = `marketflow-report-${new Date().toISOString().slice(0, 10)}.xls`; link.click(); URL.revokeObjectURL(url) }
  const exportPdf = () => { if (!report) return; const pdf = new jsPDF(); pdf.setFontSize(18); pdf.text('MarketFlow Sales Report', 14, 18); pdf.setFontSize(10); pdf.text(`Generated: ${new Date().toLocaleString('en-EG')}`, 14, 27); pdf.text(`Sales today: ${todaySales.toFixed(2)} EGP`, 14, 38); pdf.text(`Total sales: ${totalSales.toFixed(2)} EGP`, 14, 46); pdf.text(`Completed invoices: ${completed.length}`, 14, 54); pdf.setFontSize(12); pdf.text('Best sellers', 14, 68); pdf.setFontSize(10); bestRows.forEach(([productId, quantity], index) => { const name = products.find((item) => Number(item.id) === productId)?.name.en || `#${productId}`; pdf.text(`${index + 1}. ${name} — ${quantity} units`, 18, 78 + index * 8) }); pdf.save(`marketflow-report-${new Date().toISOString().slice(0, 10)}.pdf`) }
  return <section className="reports-view"><div className="dashboard-cards"><MetricCard icon={<Banknote size={19} />} tone="green" value={todaySales} label={locale === 'ar' ? 'مبيعات اليوم' : 'Sales today'} trend="EGP" /><MetricCard icon={<TrendingUp size={19} />} tone="blue" value={totalSales} label={locale === 'ar' ? 'إجمالي المبيعات' : 'Total sales'} trend={`${completed.length} ${locale === 'ar' ? 'فاتورة' : 'invoices'}`} /><MetricCard icon={<ShoppingCart size={19} />} tone="mint" value={completed.length} label={locale === 'ar' ? 'الفواتير المكتملة' : 'Completed invoices'} trend={locale === 'ar' ? 'بيانات حقيقية' : 'Live data'} /></div><section className="panel report-panel"><div className="panel-heading"><div><span className="eyebrow muted">{locale === 'ar' ? 'التقارير' : 'Reports'}</span><h2>{locale === 'ar' ? 'تصدير البيانات' : 'Export reports'}</h2></div><div className="report-actions"><button className="secondary-button" type="button" disabled={!report} onClick={exportExcel}><FileSpreadsheet size={15} />Excel</button><button className="secondary-button" type="button" disabled={!report} onClick={exportPdf}><FileDown size={15} />PDF</button></div></div><div className="report-divider" /><div className="panel-heading"><div><span className="eyebrow muted">{locale === 'ar' ? 'الأكثر مبيعاً' : 'Best sellers'}</span><h2>{locale === 'ar' ? 'أصناف الفترة الحالية' : 'Top products in loaded sales'}</h2></div><TrendingUp size={19} className="panel-heading-icon" /></div>{error ? <p className="form-error"><CircleAlert size={15} />{error}</p> : !report ? <div className="shift-empty"><Clock3 size={22} /><small>{locale === 'ar' ? 'جارٍ تحميل التقرير...' : 'Loading report...'}</small></div> : <div className="report-list">{bestRows.map(([productId, quantity]) => { const product = products.find((item) => Number(item.id) === productId); return <div className="report-row" key={productId}><span><strong>{product ? text(locale, product.name) : `#${productId}`}</strong><small>{locale === 'ar' ? 'الكمية المباعة' : 'Units sold'}</small></span><b>{quantity}</b></div> })}{!bestRows.length && <div className="shift-empty"><Package size={22} /><small>{locale === 'ar' ? 'لا توجد مبيعات بعد.' : 'No sales yet.'}</small></div>}</div>}</section></section>
}

function ShiftView({ locale, role }: { locale: Locale; role: StaffRole }) {
  const [shift, setShift] = useState<RemoteShift | null>(null)
  const [counted, setCounted] = useState(0)
  const [floatLeft, setFloatLeft] = useState(0)
  const [note, setNote] = useState('')
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  useEffect(() => { void getOpenRemoteShift().then(setShift).catch((error) => setMessage(error instanceof Error ? error.message : 'Could not load shift')) }, [])
  const close = async () => { if (!shift || busy) return; setBusy(true); setMessage(''); try { const result = await closeRemoteShift(shift.id, counted, floatLeft, note); setShift(result.shift); setMessage(locale === 'ar' ? 'تم إغلاق الوردية وتسجيل التسليم.' : 'Shift closed and handover recorded.') } catch (error) { setMessage(error instanceof Error ? error.message : (locale === 'ar' ? 'تعذر إغلاق الوردية.' : 'Could not close shift.')) } finally { setBusy(false) } }
  return <section className="panel shift-panel"><div className="panel-heading"><div><span className="eyebrow muted">{locale === 'ar' ? 'الوردية والتسليم' : 'Shift and handover'}</span><h2>{locale === 'ar' ? 'إغلاق الوردية' : 'Close shift'}</h2></div><Clock3 size={19} className="panel-heading-icon" /></div>{!shift ? <div className="shift-empty"><CircleCheck size={24} /><strong>{locale === 'ar' ? 'لا توجد وردية مفتوحة حالياً' : 'No open shift found'}</strong><small>{role === 'owner' ? (locale === 'ar' ? 'يمكنك فتح وردية من POS.' : 'Open a shift from POS when needed.') : (locale === 'ar' ? 'افتح وردية من تبويب POS.' : 'Open a shift from the POS tab.')}</small></div> : <><div className="shift-summary"><div><span>{locale === 'ar' ? 'النقدية الافتتاحية' : 'Opening cash'}</span><strong>{formatMoney(shift.opening_cash, locale)}</strong></div><div><span>{locale === 'ar' ? 'الحالة' : 'Status'}</span><strong className="status-pill available">{locale === 'ar' ? 'مفتوحة' : 'Open'}</strong></div></div><div className="form-grid two shift-form"><label>{locale === 'ar' ? 'النقدية الفعلية' : 'Counted cash'}<input min="0" type="number" value={counted || ''} onChange={(event) => setCounted(Number(event.target.value) || 0)} /></label><label>{locale === 'ar' ? 'المبلغ المتروك للوردية القادمة' : 'Float left'}<input min="0" type="number" value={floatLeft || ''} onChange={(event) => setFloatLeft(Number(event.target.value) || 0)} /></label></div><label className="shift-note">{locale === 'ar' ? 'ملاحظة' : 'Note'}<textarea value={note} onChange={(event) => setNote(event.target.value)} rows={3} /></label><button className="primary-button" type="button" disabled={busy} onClick={() => void close()}><Check size={16} />{busy ? (locale === 'ar' ? 'جارٍ الحفظ...' : 'Saving...') : (locale === 'ar' ? 'إغلاق وتسليم' : 'Close and hand over')}</button></>}{message && <p className="form-success"><CircleCheck size={15} />{message}</p>}</section>
}

function StaffManagementView({ locale }: { locale: Locale }) {
  const [cashiers, setCashiers] = useState<CashierRecord[]>([])
  const [form, setForm] = useState({ fullName: '', username: '', password: '', phone: '' })
  const [message, setMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const load = async () => { try { const result = await manageCashier('list_cashiers'); setCashiers(result.data || []) } catch (error) { setMessage(error instanceof Error ? error.message : (locale === 'ar' ? 'انشر Edge Function أولاً.' : 'Deploy the Edge Function first.')) } }
  useEffect(() => { void load() }, [])
  const create = async (event: FormEvent) => { event.preventDefault(); if (busy) return; setBusy(true); setMessage(''); try { const result = await manageCashier('create_cashier', form); setMessage(`${locale === 'ar' ? 'تم إنشاء الكاشير:' : 'Cashier created:'} ${result.username || form.username}`); setForm({ fullName: '', username: '', password: '', phone: '' }); await load() } catch (error) { setMessage(error instanceof Error ? error.message : (locale === 'ar' ? 'تعذر إنشاء الحساب.' : 'Could not create account.')) } finally { setBusy(false) } }
  const toggle = async (cashier: CashierRecord) => { try { await manageCashier('set_status', { userId: cashier.id, status: cashier.status === 'active' ? 'disabled' : 'active' }); await load() } catch (error) { setMessage(error instanceof Error ? error.message : 'Operation failed') } }
  return <section className="staff-management-grid"><section className="panel"><div className="panel-heading"><div><span className="eyebrow muted">{locale === 'ar' ? 'حسابات الموظفين' : 'Staff accounts'}</span><h2>{locale === 'ar' ? 'إضافة كاشير' : 'Create cashier'}</h2></div><ShieldCheck size={19} className="panel-heading-icon" /></div><form className="editor-form compact" onSubmit={create}><label>{locale === 'ar' ? 'الاسم' : 'Full name'}<input required value={form.fullName} onChange={(event) => setForm({ ...form, fullName: event.target.value })} /></label><label dir="ltr">Username<input required pattern="[A-Za-z0-9]+" value={form.username} onChange={(event) => setForm({ ...form, username: event.target.value })} placeholder="cashier01" /></label><label dir="ltr">Password<input required minLength={8} value={form.password} onChange={(event) => setForm({ ...form, password: event.target.value })} type="password" /></label><label dir="ltr">Phone<input value={form.phone} onChange={(event) => setForm({ ...form, phone: event.target.value })} /></label><button className="primary-button" type="submit" disabled={busy}><Plus size={16} />{locale === 'ar' ? 'إنشاء الحساب' : 'Create account'}</button></form>{message && <p className="form-success"><CircleCheck size={15} />{message}</p>}</section><section className="panel"><div className="panel-heading"><div><span className="eyebrow muted">{locale === 'ar' ? 'الحسابات الحالية' : 'Current accounts'}</span><h2>{locale === 'ar' ? 'الكاشير' : 'Cashiers'}</h2></div></div><div className="cashier-list">{cashiers.map((cashier) => <div className="cashier-row" key={cashier.id}><span className="avatar">{(cashier.full_name || cashier.username).slice(0, 1).toUpperCase()}</span><span><strong>{cashier.full_name || cashier.username}</strong><small>{cashier.username}{cashier.phone ? ` · ${cashier.phone}` : ''}</small></span><button type="button" className={`status-pill ${cashier.status === 'active' ? 'available' : 'unavailable'}`} onClick={() => void toggle(cashier)}>{cashier.status === 'active' ? (locale === 'ar' ? 'نشط' : 'Active') : (locale === 'ar' ? 'معطل' : 'Disabled')}</button></div>)}{!cashiers.length && <div className="shift-empty"><Package size={22} /><small>{locale === 'ar' ? 'لا توجد حسابات أو لم يتم نشر Edge Function بعد.' : 'No accounts, or the Edge Function is not deployed yet.'}</small></div>}</div></section></section>
}

type SaleLine = { productId: string; quantity: number }

function printReceipt(locale: Locale, lines: Array<{ name: string; quantity: number; price: number }>, total: number, invoiceId?: number) {
  const popup = window.open('', '_blank', 'width=420,height=720')
  if (!popup) return
  const title = locale === 'ar' ? 'إيصال MarketFlow' : 'MarketFlow Receipt'
  const rows = lines.map((line) => `<tr><td>${line.name}</td><td>${line.quantity}</td><td>${formatMoney(line.price * line.quantity, locale)}</td></tr>`).join('')
  popup.document.write(`<!doctype html><html lang="${locale}" dir="${locale === 'ar' ? 'rtl' : 'ltr'}"><head><meta charset="utf-8"><title>${title}</title><style>@page{size:80mm auto;margin:0}*{box-sizing:border-box}body{width:80mm;margin:0;padding:5mm 4mm;font-family:Arial,sans-serif;color:#111;font-size:12px}h1{font-size:18px;text-align:center;margin:0 0 4px}p{margin:3px 0;text-align:center;font-size:10px}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{padding:5px 2px;border-bottom:1px dashed #999;text-align:start;font-size:10px}th:last-child,td:last-child{text-align:end}.total{display:flex;justify-content:space-between;border-top:2px solid #111;margin-top:10px;padding-top:8px;font-size:15px;font-weight:bold}</style></head><body><h1>MarketFlow</h1><p>${title}${invoiceId ? ` #${invoiceId}` : ''}</p><p>${new Date().toLocaleString(locale === 'ar' ? 'ar-EG' : 'en-EG')}</p><table><thead><tr><th>${locale === 'ar' ? 'الصنف' : 'Item'}</th><th>${locale === 'ar' ? 'الكمية' : 'Qty'}</th><th>${locale === 'ar' ? 'الإجمالي' : 'Total'}</th></tr></thead><tbody>${rows}</tbody></table><div class="total"><span>${locale === 'ar' ? 'الإجمالي' : 'Total'}</span><span>${formatMoney(total, locale)}</span></div><p>${locale === 'ar' ? 'شكراً لزيارتكم' : 'Thank you for shopping with us'}</p><script>window.onload=()=>{window.print();window.onafterprint=()=>window.close()}</script></body></html>`)
  popup.document.close()
}

function PosView({ locale, products, onSaleComplete }: { locale: Locale; products: Product[]; onSaleComplete: (sold: SaleLine[]) => void }) {
  const [search, setSearch] = useState('')
  const [cart, setCart] = useState<SaleLine[]>([])
  const [payment, setPayment] = useState<'cash' | 'card'>('cash')
  const [discount, setDiscount] = useState(0)
  const [openingCash, setOpeningCash] = useState(0)
  const [shiftOpen, setShiftOpen] = useState(false)
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [lastReceipt, setLastReceipt] = useState<{ lines: Array<{ name: string; quantity: number; price: number }>; total: number; invoiceId?: number } | null>(null)
  const matches = products.filter((product) => product.availability === 'in_stock' && `${product.name.ar} ${product.name.en}`.toLocaleLowerCase().includes(search.toLocaleLowerCase())).slice(0, 8)
  const total = cart.reduce((sum, line) => sum + (products.find((product) => product.id === line.productId)?.price ?? 0) * line.quantity, 0)
  const add = (product: Product) => setCart((current) => { const existing = current.find((line) => line.productId === product.id); return existing ? current.map((line) => line.productId === product.id ? { ...line, quantity: Math.min(line.quantity + 1, product.stock ?? 1) } : line) : [...current, { productId: product.id, quantity: 1 }] })
  const checkout = async () => {
    if (!shiftOpen || !cart.length || busy) return
    setBusy(true); setMessage('')
    try {
      const result = await createRemoteSale(cart, payment, discount)
      setLastReceipt({ lines: cart.flatMap((line) => { const product = products.find((item) => item.id === line.productId); return product ? [{ name: text(locale, product.name), quantity: line.quantity, price: product.price }] : [] }), total: Math.max(0, total - discount), invoiceId: Number((result.invoice as { id?: number } | null)?.id) || undefined })
      onSaleComplete(cart)
      setCart([]); setDiscount(0)
      setMessage(locale === 'ar' ? 'تمت الفاتورة. الأسعار والعروض حُسبت من الخادم.' : 'Sale completed. Prices and offers were calculated by the server.')
    } catch (error) {
      setMessage(error instanceof Error ? error.message : (locale === 'ar' ? 'تعذر إتمام البيع. تأكد من فتح وردية.' : 'Sale failed. Make sure a shift is open.'))
    } finally { setBusy(false) }
  }
  const openShift = async () => { setBusy(true); setMessage(''); try { await openRemoteShift(openingCash); setShiftOpen(true); setMessage(locale === 'ar' ? 'تم فتح الوردية.' : 'Shift opened.') } catch (error) { setMessage(error instanceof Error ? error.message : (locale === 'ar' ? 'تعذر فتح الوردية.' : 'Could not open shift.')) } finally { setBusy(false) } }
  return <section className="pos-layout"><div className="pos-catalog panel"><div className="panel-heading"><div><span className="eyebrow muted">{locale === 'ar' ? 'نقطة البيع' : 'Point of sale'}</span><h2>{locale === 'ar' ? 'بيع سريع وآمن' : 'Fast, server-priced checkout'}</h2></div><span className={`pos-shift-badge ${shiftOpen ? 'shift-open' : ''}`}><span className="live-dot" />{shiftOpen ? (locale === 'ar' ? 'الوردية مفتوحة' : 'Shift open') : (locale === 'ar' ? 'افتح الوردية أولاً' : 'Open a shift first')}</span></div>{!shiftOpen && <div className="shift-gate"><label>{locale === 'ar' ? 'النقدية الافتتاحية' : 'Opening cash'}<input min="0" type="number" value={openingCash || ''} onChange={(event) => setOpeningCash(Number(event.target.value) || 0)} /></label><button className="primary-button" type="button" disabled={busy} onClick={() => void openShift()}><Check size={16} />{locale === 'ar' ? 'فتح الوردية' : 'Open shift'}</button></div>}<div className="inventory-search pos-search"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={locale === 'ar' ? 'ابحث باسم المنتج...' : 'Search by product name...'} /></div><div className="pos-products">{matches.map((product) => <button className="pos-product" type="button" key={product.id} disabled={!shiftOpen} onClick={() => add(product)}><span className="table-thumb">{PRODUCT_VISUALS[product.image]?.emoji}</span><span><strong>{text(locale, product.name)}</strong><small>{formatMoney(product.price, locale)} · {product.stock ?? 0}</small></span><Plus size={16} /></button>)}{!matches.length && <div className="inventory-empty"><Package size={24} /><strong>{locale === 'ar' ? 'لا توجد منتجات متاحة' : 'No available products'}</strong></div>}</div></div><aside className="pos-cart panel"><div className="panel-heading"><div><span className="eyebrow muted">{locale === 'ar' ? 'الفاتورة الحالية' : 'Current invoice'}</span><h2><ShoppingCart size={18} /> {cart.length} {locale === 'ar' ? 'أصناف' : 'items'}</h2></div></div><div className="pos-cart-lines">{cart.map((line) => { const product = products.find((item) => item.id === line.productId); if (!product) return null; return <div className="pos-cart-line" key={line.productId}><span><strong>{text(locale, product.name)}</strong><small>{formatMoney(product.price, locale)}</small></span><div><button type="button" onClick={() => setCart((current) => current.map((item) => item.productId === line.productId ? { ...item, quantity: item.quantity - 1 } : item).filter((item) => item.quantity > 0))}>−</button><b>{line.quantity}</b><button type="button" onClick={() => add(product)}>+</button></div></div> })}</div><label className="pos-discount">{locale === 'ar' ? 'خصم الفاتورة' : 'Invoice discount'}<input min="0" max={total} type="number" value={discount || ''} onChange={(event) => setDiscount(Math.min(total, Number(event.target.value) || 0))} /></label><div className="pos-total"><span>{locale === 'ar' ? 'الإجمالي' : 'Total'}</span><strong>{formatMoney(Math.max(0, total - discount), locale)}</strong></div><div className="pos-payment"><button type="button" className={payment === 'cash' ? 'selected' : ''} onClick={() => setPayment('cash')}><Banknote size={16} />{locale === 'ar' ? 'كاش' : 'Cash'}</button><button type="button" className={payment === 'card' ? 'selected' : ''} onClick={() => setPayment('card')}><CreditCard size={16} />{locale === 'ar' ? 'بطاقة' : 'Card'}</button></div><button className="primary-button full" type="button" disabled={busy || !cart.length || !shiftOpen} onClick={() => void checkout()}><Check size={17} />{busy ? (locale === 'ar' ? 'جارٍ الحفظ...' : 'Saving...') : (locale === 'ar' ? 'إتمام البيع' : 'Complete sale')}</button>{lastReceipt && <button className="secondary-button full receipt-button" type="button" onClick={() => printReceipt(locale, lastReceipt.lines, lastReceipt.total, lastReceipt.invoiceId)}><Printer size={16} />{locale === 'ar' ? 'طباعة إيصال 80mm' : 'Print 80mm receipt'}</button>}{message && <p className="form-success"><CircleCheck size={15} />{message}</p>}</aside></section>
}

function MetricCard({ icon, tone, value, label, trend }: { icon: React.ReactNode; tone: string; value: number; label: string; trend: string }) {
  return <article className={`metric-card ${tone}`}><span className="metric-icon">{icon}</span><div><strong>{value}</strong><span>{label}</span></div><small><TrendingUp size={12} />{trend}</small></article>
}

function OwnerInvite({ locale, onAddOwnerEmail }: { locale: Locale; onAddOwnerEmail: (email: string) => Promise<void> }) {
  const [email, setEmail] = useState('')
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)
  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if (!email.includes('@') || busy) return
    setBusy(true)
    setStatus('')
    try {
      await onAddOwnerEmail(email)
      setEmail('')
      setStatus(locale === 'ar' ? 'تمت إضافة البريد كمالك. يمكنه إنشاء حساب أو تسجيل الدخول.' : 'Owner email added. They can now sign up or sign in.')
    } catch {
      setStatus(locale === 'ar' ? 'تعذر إضافة البريد. شغّل migration الخاصة بالأدوار أولاً.' : 'Could not add email. Run the role migration first.')
    } finally {
      setBusy(false)
    }
  }
  return <section className="owner-invite panel"><div className="owner-invite-copy"><span className="auth-card-icon"><Mail size={18} /></span><div><span className="eyebrow muted">{locale === 'ar' ? 'صلاحيات المالك' : 'Owner permissions'}</span><h2>{locale === 'ar' ? 'إضافة مالك جديد' : 'Add another owner'}</h2><p>{locale === 'ar' ? 'أضف البريد، وبعد التسجيل سيأخذ دور المالك تلقائياً.' : 'Add an email and its next account will receive owner access automatically.'}</p></div></div><form className="owner-invite-form" onSubmit={submit}><input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="owner@example.com" dir="ltr" /><button className="primary-button" type="submit" disabled={busy}><Mail size={15} />{locale === 'ar' ? 'إضافة البريد' : 'Add email'}</button></form>{status && <p className="form-success"><CircleCheck size={15} />{status}</p>}</section>
}

function Overview({ locale, products, activities, onManage }: { locale: Locale; products: Product[]; activities: Activity[]; onManage: () => void }) {
  const areaBreakdown = (area: Area) => products.filter((product) => product.area === area).length
  return <div className="overview-grid"><section className="panel overview-main"><div className="panel-heading"><div><span className="eyebrow muted">{tr(locale, 'currentCatalog')}</span><h2>{tr(locale, 'manageInventory')}</h2></div><button className="ghost-button" type="button" onClick={onManage}>{tr(locale, 'inventory')}<ArrowLeft size={15} /></button></div><p className="panel-body-copy">{tr(locale, 'manageInventoryBody')}</p><div className="area-breakdown"><div className="breakdown-item"><div className="breakdown-top"><span><Store size={16} />{tr(locale, 'insideShop')}</span><strong>{areaBreakdown('inside')}</strong></div><div className="progress"><span style={{ width: `${(areaBreakdown('inside') / Math.max(products.length, 1)) * 100}%` }} /></div></div><div className="breakdown-item"><div className="breakdown-top"><span><MapPin size={16} />{tr(locale, 'outsideArea')}</span><strong>{areaBreakdown('outside')}</strong></div><div className="progress gold"><span style={{ width: `${(areaBreakdown('outside') / Math.max(products.length, 1)) * 100}%` }} /></div></div></div><div className="overview-callout"><span className="callout-icon"><Sparkles size={17} /></span><span><strong>{locale === 'ar' ? 'المتابعة اليومية أسهل هنا' : 'Daily checks feel easier here'}</strong><small>{locale === 'ar' ? 'غيّر حالة أي منتج وستظهر للزائرين فوراً.' : 'Change any product status and visitors see it instantly.'}</small></span></div></section><section className="panel activity-panel"><div className="panel-heading"><div><span className="eyebrow muted">{tr(locale, 'liveSync')}</span><h2>{tr(locale, 'latestActivity')}</h2></div><Clock3 size={18} className="panel-heading-icon" /></div><div className="activity-list">{activities.slice(0, 4).map((activity) => <div className="activity-row" key={activity.id}><span className={`activity-dot ${activity.action}`}><ActivityIcon action={activity.action} /></span><span><strong>{text(locale, activity.detail)}</strong><small>{text(locale, activity.productName)} · {formatTime(activity.at, locale)}</small></span></div>)}</div></section></div>
}

function ActivityIcon({ action }: { action: Activity['action'] }) { return action === 'created' ? <Plus size={13} /> : action === 'availability' ? <CircleAlert size={13} /> : <Edit3 size={13} /> }

function InventoryView({ locale, products, search, setSearch, area, setArea, category, setCategory, onEdit, onToggle }: { locale: Locale; products: Product[]; search: string; setSearch: (value: string) => void; area: 'all' | Area; setArea: (value: 'all' | Area) => void; category: CategoryId | 'all'; setCategory: (value: CategoryId | 'all') => void; onEdit?: (product: Product) => void; onToggle: (product: Product) => void }) {
  return <section className="inventory-panel panel"><div className="inventory-toolbar"><div className="inventory-search"><Search size={17} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={tr(locale, 'searchInventory')} aria-label={tr(locale, 'searchInventory')} /></div><div className="toolbar-selects"><label><Filter size={14} /><select value={area} onChange={(event) => setArea(event.target.value as 'all' | Area)}><option value="all">{tr(locale, 'allAreas')}</option><option value="inside">{tr(locale, 'insideShop')}</option><option value="outside">{tr(locale, 'outsideArea')}</option></select></label><label><Tag size={14} /><select value={category} onChange={(event) => setCategory(event.target.value as CategoryId | 'all')}><option value="all">{tr(locale, 'allCategories')}</option>{CATEGORY_ORDER.map((item) => <option value={item} key={item}>{categoryLabel(item, locale)}</option>)}</select></label></div></div><div className="inventory-table-wrap"><table className="inventory-table"><thead><tr><th>{tr(locale, 'productName')}</th><th>{tr(locale, 'category')}</th><th>{tr(locale, 'area')}</th><th>{tr(locale, 'price')}</th><th>{tr(locale, 'availability')}</th><th aria-label={tr(locale, 'edit')} /></tr></thead><tbody>{products.map((product) => <InventoryRow key={product.id} product={product} locale={locale} onEdit={onEdit ? () => onEdit(product) : undefined} onToggle={() => onToggle(product)} />)}</tbody></table></div>{products.length === 0 && <div className="inventory-empty"><Package size={23} /><strong>{tr(locale, 'emptyInventory')}</strong></div>}</section>
}

function InventoryRow({ product, locale, onEdit, onToggle }: { product: Product; locale: Locale; onEdit?: () => void; onToggle: () => void }) {
  const isInStock = product.availability === 'in_stock'
  const visual = PRODUCT_VISUALS[product.image] ?? PRODUCT_VISUALS.produce
  const secondaryName = locale === 'ar' ? product.name.en : product.name.ar
  return <tr><td><div className="table-product"><span className={`table-thumb ${visual.tone}`}>{visual.emoji}</span><span><strong>{text(locale, product.name)}</strong><small>{secondaryName}</small></span></div></td><td><span className="table-muted">{text(locale, product.category.label)}</span></td><td><span className="table-area"><span className={`area-dot ${product.area}`} />{areaLabel(product.area, locale)}</span></td><td><strong className="table-price">{formatMoney(product.price, locale)}</strong>{product.compareAtPrice && <small className="table-compare">{formatMoney(product.compareAtPrice, locale)}</small>}</td><td><button type="button" className={`availability-toggle ${isInStock ? 'on' : 'off'}`} onClick={onToggle} aria-label={isInStock ? tr(locale, 'unavailable') : tr(locale, 'available')}><span className="toggle-knob" />{isInStock ? tr(locale, 'available') : tr(locale, 'unavailable')}</button></td><td>{onEdit && <button type="button" className="icon-button" onClick={onEdit} aria-label={`${tr(locale, 'edit')} ${text(locale, product.name)}`}><Edit3 size={16} /></button>}</td></tr>
}

function ProductEditor({ locale, product, onCancel, onSave }: { locale: Locale; product?: Product; onCancel: () => void; onSave: (product: Product, isNew: boolean) => void }) {
  const isNew = !product
  const [form, setForm] = useState<Product>(product ?? { id: makeId(), name: { ar: '', en: '' }, category: { id: 'produce', label: CATEGORY_LABELS.produce }, area: 'inside', price: 0, availability: 'in_stock', image: 'produce', updatedAt: new Date().toISOString() })
  const update = <K extends keyof Product>(key: K, value: Product[K]) => setForm((current) => ({ ...current, [key]: value, updatedAt: new Date().toISOString() }))
  const submit = (event: FormEvent) => { event.preventDefault(); const trimmed = { ...form, name: { ar: form.name.ar.trim(), en: form.name.en.trim() }, price: Number(form.price), compareAtPrice: form.compareAtPrice ? Number(form.compareAtPrice) : undefined, offer: form.offer?.ar || form.offer?.en ? { ar: form.offer.ar.trim(), en: form.offer.en.trim() } : undefined }; if (!trimmed.name.ar || !trimmed.name.en || trimmed.price <= 0) return; onSave(trimmed, isNew) }
  return <div className="modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.currentTarget === event.target) onCancel() }}><section className="editor-modal" role="dialog" aria-modal="true" aria-labelledby="editor-title"><div className="modal-header"><div><span className="eyebrow muted">{tr(locale, 'inventory')}</span><h2 id="editor-title">{isNew ? tr(locale, 'addProduct') : tr(locale, 'edit')}</h2></div><button type="button" className="icon-button" onClick={onCancel} aria-label={tr(locale, 'close')}><X size={19} /></button></div><form className="editor-form" onSubmit={submit}><div className="form-grid two"><label>{tr(locale, 'arabicName')}<input required value={form.name.ar} onChange={(event) => update('name', { ...form.name, ar: event.target.value })} dir="rtl" /></label><label>{tr(locale, 'englishName')}<input required value={form.name.en} onChange={(event) => update('name', { ...form.name, en: event.target.value })} dir="ltr" /></label></div><div className="form-grid two"><label>{tr(locale, 'category')}<select value={form.category.id} onChange={(event) => { const id = event.target.value as CategoryId; update('category', { id, label: CATEGORY_LABELS[id] }) }}>{CATEGORY_ORDER.map((item) => <option value={item} key={item}>{categoryLabel(item, locale)}</option>)}</select></label><label>{tr(locale, 'area')}<select value={form.area} onChange={(event) => update('area', event.target.value as Area)}><option value="inside">{tr(locale, 'insideShop')}</option><option value="outside">{tr(locale, 'outsideArea')}</option></select></label></div><div className="form-grid two"><label>{tr(locale, 'price')}<input required min="1" type="number" value={form.price || ''} onChange={(event) => update('price', Number(event.target.value))} /></label><label>{tr(locale, 'compareAt')} <small>({tr(locale, 'optional')})</small><input min="0" type="number" value={form.compareAtPrice || ''} onChange={(event) => update('compareAtPrice', event.target.value ? Number(event.target.value) : undefined)} /></label></div><div className="form-grid two"><label>{tr(locale, 'offerText')} <small>({tr(locale, 'optional')})</small><input value={form.offer?.ar || ''} onChange={(event) => update('offer', { ar: event.target.value, en: form.offer?.en || '' })} placeholder={tr(locale, 'offerPlaceholder')} /></label><label>{tr(locale, 'englishName')} · {tr(locale, 'offerText')}<input value={form.offer?.en || ''} onChange={(event) => update('offer', { ar: form.offer?.ar || '', en: event.target.value })} placeholder={locale === 'ar' ? 'مثال: عرض الأسبوع' : 'Example: Weekly offer'} dir="ltr" /></label></div><div className="editor-section"><span className="editor-label">{tr(locale, 'imageStyle')}</span><div className="visual-picker">{Object.entries(PRODUCT_VISUALS).map(([key, visual]) => <button type="button" key={key} className={form.image === key ? 'selected' : ''} onClick={() => update('image', key)}><span className={`picker-thumb ${visual.tone}`}>{visual.emoji}</span></button>)}</div></div><div className="availability-picker"><span className="editor-label">{tr(locale, 'availability')}</span><div><button type="button" className={form.availability === 'in_stock' ? 'selected' : ''} onClick={() => update('availability', 'in_stock' as Availability)}><CircleCheck size={15} />{tr(locale, 'available')}</button><button type="button" className={form.availability === 'out_of_stock' ? 'selected out' : ''} onClick={() => update('availability', 'out_of_stock' as Availability)}><CircleX size={15} />{tr(locale, 'unavailable')}</button></div></div><div className="modal-actions"><button className="secondary-button" type="button" onClick={onCancel}>{tr(locale, 'cancel')}</button><button className="primary-button" type="submit"><Check size={16} />{tr(locale, 'saveProduct')}</button></div></form></section></div>
}
