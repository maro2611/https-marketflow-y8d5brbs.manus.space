import { FormEvent, useState } from 'react'
import { ArrowLeft, ArrowRight, CircleAlert, CircleCheck, Globe2, ShieldCheck, Store, UserRound } from 'lucide-react'
import { signInAccount, signOutStaff, signUpAccount } from '../../shared/supabase'
import type { Locale, UserAccount } from '../../shared/types'

interface AccountAuthProps {
  locale: Locale
  onLocaleChange: (locale: Locale) => void
  onNavigate: (path: string) => void
  onAuthenticated: (account: UserAccount | null) => void
}

export function AccountAuth({ locale, onLocaleChange, onNavigate, onAuthenticated }: AccountAuthProps) {
  const [mode, setMode] = useState<'login' | 'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const [staffAccountDetected, setStaffAccountDetected] = useState(false)
  const isArabic = locale === 'ar'

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    setError('')
    setMessage('')
    setStaffAccountDetected(false)
    if (!email.includes('@') || password.length < 6 || (mode === 'signup' && fullName.trim().length < 2)) {
      setError(isArabic ? 'اكتب البيانات المطلوبة وكلمة مرور من ٦ أحرف على الأقل.' : 'Enter the required details and a password of at least 6 characters.')
      return
    }
    try {
      if (mode === 'signup') {
        const result = await signUpAccount(email.trim(), password, fullName.trim())
        if (result.needsEmailConfirmation) {
          setMessage(isArabic ? 'تم إنشاء الحساب. راجع بريدك لتأكيد الحساب ثم سجّل الدخول.' : 'Account created. Check your email to confirm it, then sign in.')
          setMode('login')
          return
        }
        if (result.account?.role === 'owner' || result.account?.role === 'cashier') {
          await signOutStaff()
          setStaffAccountDetected(true)
          setError(isArabic ? 'هذا حساب موظفين. استخدم صفحة دخول الموظفين.' : 'This is a staff account. Use the staff login page.')
          return
        }
        onAuthenticated(result.account)
        onNavigate('/')
        return
      }
      const account = await signInAccount(email.trim(), password)
      if (account?.role === 'owner' || account?.role === 'cashier') {
        await signOutStaff()
        setStaffAccountDetected(true)
        setError(isArabic ? 'هذا حساب موظفين. استخدم صفحة دخول الموظفين.' : 'This is a staff account. Use the staff login page.')
        return
      }
      onAuthenticated(account)
      onNavigate('/')
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : (isArabic ? 'تعذر إتمام العملية.' : 'The request could not be completed.'))
    }
  }

  return <div className="account-auth-page">
    <header className="site-header container-wide"><button type="button" className="brand-button" onClick={() => onNavigate('/')}><span className="logo-mark"><Store size={19} /></span><span className="brand-copy"><strong>MarketFlow</strong><small>{isArabic ? 'حساب اختياري' : 'Optional account'}</small></span></button><div className="header-actions"><button type="button" className="catalog-back" onClick={() => onNavigate('/')}><ArrowRight size={16} />{isArabic ? 'الكتالوج' : 'Catalog'}</button><button className="locale-toggle" type="button" onClick={() => onLocaleChange(isArabic ? 'en' : 'ar')}><Globe2 size={16} />{isArabic ? 'English' : 'العربية'}</button></div></header>
    <main className="account-auth-layout container-wide">
      <section className="account-auth-intro"><span className="intro-kicker"><ShieldCheck size={16} />{isArabic ? 'تسجيل اختياري' : 'Optional sign in'}</span><h1>{isArabic ? 'ادخل بطريقتك.' : 'Enter your way.'}</h1><p>{isArabic ? 'تقدر تكمل تصفح المنتجات بدون حساب. الحساب يساعدك على حفظ هويتك، وحسابات الفريق لها صلاحيات منفصلة.' : 'You can keep browsing without an account. Accounts identify you, while team accounts receive separate permissions.'}</p><div className="account-auth-signal"><span className="live-dot" /><span><strong>{isArabic ? 'الكتالوج مفتوح للجميع' : 'Catalog stays open to everyone'}</strong><small>{isArabic ? 'لا يوجد طلب أو دفع أونلاين' : 'No online ordering or payment'}</small></span></div></section>
      <section className="account-auth-card"><div className="auth-card-icon"><UserRound size={22} /></div><div className="auth-card-heading"><span>{isArabic ? 'حساب MarketFlow' : 'MarketFlow account'}</span><h2>{mode === 'login' ? (isArabic ? 'تسجيل الدخول' : 'Sign in') : (isArabic ? 'إنشاء حساب' : 'Create account')}</h2></div><div className="auth-mode-tabs"><button type="button" className={mode === 'login' ? 'active' : ''} onClick={() => { setMode('login'); setError(''); setMessage(''); setStaffAccountDetected(false) }}>{isArabic ? 'دخول' : 'Sign in'}</button><button type="button" className={mode === 'signup' ? 'active' : ''} onClick={() => { setMode('signup'); setError(''); setMessage(''); setStaffAccountDetected(false) }}>{isArabic ? 'حساب جديد' : 'Sign up'}</button></div><form className="account-auth-form" onSubmit={submit}>{mode === 'signup' && <label>{isArabic ? 'الاسم' : 'Full name'}<input required value={fullName} onChange={(event) => setFullName(event.target.value)} autoComplete="name" placeholder={isArabic ? 'اكتب اسمك' : 'Your name'} /></label>}<label>{isArabic ? 'البريد الإلكتروني' : 'Email address'}<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" placeholder="you@example.com" dir="ltr" /></label><label>{isArabic ? 'كلمة المرور' : 'Password'}<input required type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete={mode === 'login' ? 'current-password' : 'new-password'} placeholder="••••••••" /></label>{error && <p className="form-error"><CircleAlert size={15} />{error}</p>}{message && <p className="form-success"><CircleCheck size={15} />{message}</p>}{staffAccountDetected && <button className="secondary-button full" type="button" onClick={() => onNavigate('/staff/login')}>{isArabic ? 'الانتقال إلى دخول الموظفين' : 'Go to staff login'}<ArrowLeft size={17} /></button>} {!staffAccountDetected && <button className="primary-button full" type="submit">{mode === 'login' ? (isArabic ? 'دخول' : 'Sign in') : (isArabic ? 'إنشاء الحساب' : 'Create account')}<ArrowLeft size={17} /></button>}</form><p className="auth-card-note">{isArabic ? 'حسابات المالك والكاشير تدخل من صفحة الموظفين فقط.' : 'Owner and cashier accounts sign in from the staff page only.'}</p></section>
    </main>
  </div>
}
