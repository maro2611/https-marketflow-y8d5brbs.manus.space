# MarketFlow Staff System Expansion Plan

## Scope
Expand the existing Arabic-first MarketFlow PWA into a production staff workspace for two roles: `owner` and `cashier`. Customer browsing remains public and view-only. Staff authentication is available only through `/staff/login`; `/login` is customer-only.

## Architecture
- Keep the Vite React SPA and PWA shell.
- Use Supabase Auth for identities and Postgres/RLS for authorization.
- Use server-side SQL functions and Supabase Edge Functions for account administration, checkout, returns, inventory mutations, password resets, and disabled-account checks.
- Never expose the Supabase service-role key to the browser.
- Keep public product reads limited to active products, stock availability, prices, and running offers.
- Use Realtime for products, offers, orders, and shift/handover status changes.

## Data model
Add tables for staff profiles, products/catalog metadata, offers, shifts, invoices, invoice items, delivery orders/items, inventory movements, handovers, audit events, and rate-limit attempts. Add indexes and RLS policies for role-scoped reads/writes. Store money as integer EGP piastres or numeric server-side values consistently; expose formatted EGP in the UI.

## Server operations
- Owner-only Edge Functions: create/reset/disable/enable/rename/delete cashier, export reports, confirm handover, owner comments, product/offer administration, returns/cancellations.
- Cashier/owner functions: open/close shift, create sale, create/update delivery order, read own invoices and active delivery orders.
- Sale function validates open shift, role, disabled state, current price/offer, stock, payment method, discount limits, atomically deducts stock, writes invoice/items/movement/audit.
- Close-shift function computes expected cash, difference, float, handover and immutable summary.

## Frontend areas
- Staff login with username/password.
- Cashier workspace: shift gate, POS, barcode input/camera integration seam, cart, payment, receipt, delivery orders, close-shift flow.
- Owner workspace: dashboard, products, offers, inventory, invoices/orders, shifts, staff, audit, reports.
- Role-specific navigation and server error states; UI guards are convenience only, never the authorization boundary.

## Delivery stages
1. Database migration, functions, RLS, Edge Function source, and seed data.
2. Staff account management and staff-only login.
3. Cashier shift/POS/order flows.
4. Owner dashboard and management tabs.
5. Reports, realtime, receipt/print, responsive polish, PWA/Capacitor notes.
6. Typecheck, build, route/security review, and setup documentation.

## Current constraint
The browser has only a publishable Supabase key. The migration and Edge Function source can be committed, but applying migrations/deploying functions requires the project owner to run them in Supabase Dashboard or provide an authorized server-side deployment route. No service-role secret will be placed in `.env`, source, or client bundles.
