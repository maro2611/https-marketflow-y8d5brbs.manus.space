# MarketFlow Supermarket Management

MarketFlow is an Arabic-first, bilingual supermarket catalog and staff workspace for one store with an inside shop and outside area. The customer experience is view-only; staff use the protected workspace to update inventory.

## Product behavior

- Customer catalog opens without an account or checkout.
- Customers can optionally sign up or sign in from `/login`; browsing remains fully available without an account.
- Arabic RTL is the default; the language toggle persists.
- Search, category and area filters, offers, prices, stock state, PWA install metadata, and offline shell are included.
- Supabase Auth protects the staff route.
- `owner` can manage product details; `cashier` can update stock through the `update_product_stock` RPC.
- Supabase Realtime refreshes the catalog after product changes.
- Owners can add future owner emails from the dashboard; those emails receive `owner` automatically when they sign up.
- POS can print the latest completed invoice as an 80mm thermal receipt.
- Owner Reports can export loaded invoices and best-seller data as Excel-compatible `.xls` or `.pdf` files.

## Local development

```bash
pnpm install
pnpm dev --host 0.0.0.0 --port 3000
```

Environment variables are read from `.env`:

```text
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-publishable-key
```

## Demo catalog seed

The live project currently has an existing `products` table with base fields. Run [`supabase/demo_seed.sql`](supabase/demo_seed.sql) once in the Supabase SQL Editor to add the catalog columns and insert twelve bilingual demo products across both areas, including offers and an out-of-stock item. The script is idempotent and will not duplicate the named demo rows.

Run [`supabase/roles_and_optional_auth.sql`](supabase/roles_and_optional_auth.sql) after it to create the owner allowlist RPC and the new-user role trigger. Bootstrap the first owner by replacing the placeholder email in the commented SQL at the end of that file, then use the Owner dashboard to add additional owner emails.

## Schema compatibility

The client reads the current base schema (`id`, `name`, `price`, `stock`, `active`, `updated_at`) and defaults area/category when the extended columns are not present. After the demo migration, it reads and writes bilingual names, area, category, offers, comparison prices, image presets, and active state. Owner saves try the extended payload first and fall back to the base schema when an older database is still deployed.

The electronic visual direction uses a dark command-center canvas, neon cyan status signals, blue telemetry accents, glass surfaces, grid overlays, and responsive layouts suitable for a future Capacitor wrapper.

## Staff system foundation

The expanded staff specification is documented in [`staff-system-plan.md`](staff-system-plan.md).
The additive database foundation is [`supabase/staff_system.sql`](supabase/staff_system.sql); run it in Supabase SQL Editor after the catalog and role migrations. It adds staff metadata, offers, shifts, invoices, delivery orders, inventory movements, handovers, audit logs, RLS, and server-side shift/stock functions.

The attached standalone management UI is now the Vite entrypoint (`index.html`). Run [`supabase/staff2.sql`](supabase/staff2.sql) after the base migrations to add the compatibility tables and RPCs used by the UI. The owner-only cashier account lifecycle source is [`supabase/functions/staff-admin/index.ts`](supabase/functions/staff-admin/index.ts). Deploy it as a Supabase Edge Function and configure the platform-provided `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` secrets. The service-role key must never be copied into `.env`, the browser bundle, or frontend source.

If the staff migration was already applied before the latest security fixes, run [`supabase/security_fix.sql`](supabase/security_fix.sql) once in the Supabase SQL Editor. It adds any missing catalog columns, permits authenticated users to read their own profile, and prevents anonymous clients from selecting the private `products.cost` column.

The current verified owner email is `marcelinofahmyatiia@gmail.com`. Staff access is through `/staff/login`; `/login` is reserved for customer accounts.
