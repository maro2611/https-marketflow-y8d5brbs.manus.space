# MarketFlow design brief

## Direction

**Market-operations editorial dashboard** — a warm, highly legible supermarket system that feels closer to a well-run neighborhood store than a generic admin template. The visual language balances a calm cream canvas with deep ink typography, a confident produce-green signature color, and citrus highlights that make offers easy to spot.

## Principles

The catalog should feel welcoming and quick to scan, while the staff console should feel focused and operational. Use large intentional cards for products, a compact but breathable table for inventory, and consistent rounded geometry to make the interface feel friendly on touch devices. Contrast, spacing, and status labels do most of the communication work; color reinforces, but never replaces, text.

## Palette

- **Canvas:** warm cream `#f7f5ef`
- **Surface:** white `#fffdfa`
- **Ink:** deep forest charcoal `#17241c`
- **Muted:** sage grey `#718078`
- **Brand:** produce green `#2f6b49`
- **Brand soft:** mint `#e0efe6`
- **Offer:** citrus gold `#f2b84b`
- **Offer soft:** pale lemon `#fff2c9`
- **Alert:** tomato red `#c84b45`

## Layout and interaction

The header is a quiet navigation rail on desktop that collapses into a compact top bar on mobile. Catalog filters sit in an elevated control strip. Product visuals use softly tinted, CSS-rendered still-life illustrations so the page has a distinct identity without remote image dependencies. Staff actions are optimistic and immediately visible, with a small synced-state cue rather than intrusive notifications.

## Type

Use a system stack that renders Arabic well: `"IBM Plex Sans Arabic", "Noto Sans Arabic", "Segoe UI", sans-serif` with a strong fallback. Display text is weighty and slightly tight; body copy is relaxed; numerical data uses tabular figures. Keep line lengths short in cards and use strong label/value pairings in the dashboard.

## Brand essence and voice

MarketFlow is the organized heart of the store: clear, warm, current. Copy is direct and reassuring, with Arabic as the primary voice and English as a dependable alternative. Avoid ecommerce language that implies ordering; say **Browse**, **Available**, **Offer**, and **Staff workspace**.

## Wordmark and icon

A flat basket-and-leaf mark: two filled arch shapes create an open basket, with a single leaf cutout creating negative space. The silhouette should remain recognizable at 24px. Use the mark in green on the header and as a full-bleed square green PWA icon with cream symbol.
